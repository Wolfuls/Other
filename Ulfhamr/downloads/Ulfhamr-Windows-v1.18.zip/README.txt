﻿情報拡張装置【ウールヴハム】 Windows v1.18
ZIPを展開して Ulfhamr.exe を起動してください。64bit Windows / WebView2 Runtime が必要です。
既存データの保存先は変更していません。
今回の変更：ステータス全体の一括コピー、上部ボタンの整理、独立したフェイズ行、
ホバー強調、キャラクター設定からリコリス用コマZIPの書き出し。
リコリスの開いている相手コマの読み取りはFirefox拡張機能で利用できます。

配布ページ・取扱説明書：https://wolfuls.github.io/Other/Ulfhamr/
