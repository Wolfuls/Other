/* Browser-local session manager. No character data is sent to the server. */
(()=>{'use strict';
let uiDocument=document;
const surfaces=new Map([[document,{tab:"actions"}]]), popupTitles={actions:"行動一覧",compare:"期待値",buffs:"盤面の補正"};
const Y=Ygg,$=s=>uiDocument.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const WINDOWS_FILE='Ulfhamr-Windows-v1.37.zip',WINDOWS_DOWNLOAD='https://wolfuls.github.io/Other/Ulfhamr/downloads/'+WINDOWS_FILE;
const firefoxMode=!!document.getElementById('lycoris-integration');
const KEY='ygg-round-v1';let db={version:1,characters:[],activeId:null},storageError='';
const Theme=UlfTheme,THEME_KEY='ulfhamr-theme-v2',LEGACY_THEME_KEY='ulfhamr-theme-v1';
let themeState=Theme.preset('light'),colorTheme=themeState.base;
try{themeState=Theme.read(UlfStorage.getItem(THEME_KEY),UlfStorage.getItem(LEGACY_THEME_KEY));colorTheme=themeState.base;}catch(e){}
Theme.apply(document,themeState);
try{const raw=UlfStorage.getItem(KEY);if(raw)db=Y.validateDatabase(JSON.parse(raw));}catch(e){storageError='保存データを読めませんでした。元データは上書きせず保持しています。バックアップを書き出してから確認してください。';}
let tab='actions',draft=[],desperate=0,note='',search='',selectedActions={},pendingImport=null,importMode='progress',compareOpts={selection:'auto',includeDraft:true,mode:'cf',tie:'reroll',minimum:0};
let compactDesktop=false;
const c=()=>db.characters.find(x=>x.id===db.activeId)||db.characters[0];
const symbol='<img class="app-emblem" src="Ulfhamr.svg" alt="">';
window.addEventListener('ulfhamr-storage-error',e=>{storageError=e.detail;toast(storageError);let banner=document.getElementById('storage-failure');if(!banner){banner=document.createElement('div');banner.id='storage-failure';banner.className='error';banner.setAttribute('role','alert');document.body.prepend(banner);}banner.textContent=storageError;});
function toast(text){const target=$('#toast');target.textContent=text;target.classList.add('show');clearTimeout(target.timer);target.timer=setTimeout(()=>target.classList.remove('show'),4500);}
function syncTheme(){
 for(const doc of surfaces.keys()){
  Theme.apply(doc,themeState);
  for(const button of doc.querySelectorAll('[data-do="set-theme"]')){
   const active=button.dataset.theme===colorTheme;button.setAttribute('aria-pressed',String(active));button.classList.toggle('active',active);
  }
  for(const input of doc.querySelectorAll('[data-theme-color]')){
   const value=themeState.colors[input.dataset.themeColor];
   if(value&&doc.activeElement!==input){input.value=value;input.removeAttribute('aria-invalid');}
  }
  const summary=doc.querySelector('[data-theme-summary]');if(summary)summary.textContent=(colorTheme==='dark'?'ダーク':'ライト')+'をベース'+(Theme.customized(themeState)?'（色を調整済み）':'');
 }
 if(window.chrome?.webview)window.chrome.webview.postMessage(Theme.nativeMessage(themeState));
}
function persistTheme(){
 try{UlfStorage.setItem(THEME_KEY,JSON.stringify(themeState));UlfStorage.setItem(LEGACY_THEME_KEY,colorTheme);return true;}
 catch(e){toast('テーマを保存できませんでした。');return false;}
}
function setTheme(next){
 if(!['light','dark'].includes(next))return;
 themeState=Theme.preset(next);colorTheme=themeState.base;persistTheme();syncTheme();
}
function setThemeColor(el){
 const value=el.value.trim();if(!Theme.validColor(value)){el.setAttribute('aria-invalid','true');return;}
 el.removeAttribute('aria-invalid');themeState=Theme.withColor(themeState,el.dataset.themeColor,value);persistTheme();syncTheme();
}
window.addEventListener('storage',e=>{if(e.key===THEME_KEY){themeState=Theme.read(e.newValue,'light');colorTheme=themeState.base;syncTheme();}});
function save(){if(storageError){toast(storageError);return false;}try{UlfStorage.setItem(KEY,JSON.stringify(db));return true;}catch(e){storageError='端末への保存に失敗しました。バックアップを書き出してください。';toast(storageError);return false;}}
function download(data,name,type='application/json'){const a=uiDocument.createElement('a');a.href=URL.createObjectURL(new Blob([data],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);}
function input(name,label,value,type='number',attrs=''){return `<label>${label}<input name="${name}" type="${type}" value="${esc(value)}" ${type==='number'?'step="1"':''} ${attrs}></label>`;}
function select(name,label,value,options){return `<label>${label}<select name="${name}">${options.map(o=>{const[v,l]=Array.isArray(o)?o:[o,o];return `<option value="${esc(v)}" ${String(value)===String(v)?'selected':''}>${esc(l)}</option>`}).join('')}</select></label>`;}
function modal(title,body,sub=''){ $('#modal-content').innerHTML=`${c()&&uiDocument===document?'<div class="modal-resources">'+resourceBar(c())+'</div>':''}<div class="modal-title"><div><h2>${title}</h2>${sub?`<p>${sub}</p>`:''}</div><button data-do="close" class="ghost" aria-label="閉じる">×</button></div>${body}`;if(!$('#modal').open)$('#modal').showModal();syncSurfaceLocks();}
function resource(label,key,max,cls=''){const v=c().state[key];return `<span class="resource ${cls}"><span class="resource-label">${label}${key==='rage'?' %':key==='factor'?' Rd':''}</span><span class="resource-value">${v}<small>${max?' / '+max:''}</small></span></span>`;}
function resourceBar(char){const s=char.state;return `<button type="button" class="resource-grid resource-copy-panel" data-do="copy-status" aria-label="現在の状態をまとめてコピー" title="クリックで全状態を1行にまとめてコピー">${resource('HP','hp',s.hpMax)}${resource('PP','pp',s.ppMax)}${resource('暴走率','rage',0,'rage')}${resource('因子','factor',0,'factor')}${resource('総消費 PP','spent',0)}${['spe','karma'].map(key=>`<span class="resource resource-ability"><span class="resource-label">${key==='spe'?'SPE':'カルマ'}</span><span class="ability-value">${esc(Y.resourceCopy(char,key).replace(/^(SPE|カルマ) /,''))}</span></span>`).join('')}</button>`;}
function characterStatus(char){return `<div class="character-status"><div class="character-title"><select id="companion-character" aria-label="キャラクター">${db.characters.map(x=>`<option value="${esc(x.id)}" ${x.id===char.id?'selected':''}>${esc(x.name)}</option>`).join('')}</select><button class="small" data-do="import" title="キャラシートを読み込む">＋ 読込</button></div>${resourceBar(char)}</div>`;}
async function exportToken(){const char=c();if(!char)return;try{const bytes=await UlfToken.archive(char,Y,JSZip,UlfTokenImage);download(bytes,'Ulfhamr-Token.zip','application/zip');toast('コマを書き出しました。ZIPをリコリスへドロップし、コマのシートを開いて相手を選択してください。');}catch(e){toast('コマを書き出せませんでした：'+e.message);}}
function renderOne(){const char=c();if(char&&!db.activeId)db.activeId=char.id;
$('#app').innerHTML=`<div class="app-shell"><aside class="sidebar"><div class="brand"><div class="brand-mark">${symbol}</div><div><strong>情報拡張装置<br>【ウールヴハム】</strong><small>SESSION COMPANION</small></div></div><div><div class="side-label">CHARACTERS <span>${db.characters.length.toString().padStart(2,'0')}</span></div><div class="side-characters">${db.characters.map((x,i)=>`<button class="character ${char?.id===x.id?'active':''}" data-do="switch" data-id="${esc(x.id)}"><span class="avatar">${(i+1).toString().padStart(2,'0')}</span><span class="char-text"><b>${esc(x.name)}</b><small>${esc(x.activation)} / ${Y.isBattle(x.state)?'R'+x.state.round:'探索中'}</small></span></button>`).join('')}<button class="import" data-do="import">＋ キャラシートを読込</button></div></div><div class="sidebar-bottom"><div class="backup-actions"><button data-do="export">バックアップ</button><button data-do="restore-file">復元</button><button data-do="manual">手動作成</button></div><p><span class="local-dot"></span>この端末に自動保存</p><p>キャラのデータはブラウザ内に保存されます。</p><a href="https://wolfuls.github.io/YggRW/index.html" target="_blank" rel="noopener">ユグドラシルRW ルール ↗</a></div></aside><main class="main">${char?sessionHeader(char):`<div class="empty-toolbar"><span>情報拡張装置【ウールヴハム】</span><button class="small" data-do="options">⚙ オプション</button></div>`}${storageError?`<div class="error">${storageError}<button data-do="export-raw">元データを書出</button></div>`:''}${char?board(char):welcome()}</main></div>`;
uiDocument.body.classList.toggle('companion-mode',compactDesktop);uiDocument.body.classList.toggle('firefox-mode',firefoxMode);if(char&&['draft','compare'].includes(tab))calculate();
if(window.chrome?.webview)window.chrome.webview.postMessage(Theme.nativeMessage(themeState));
 if(window.chrome?.webview)window.chrome.webview.postMessage('tray:'+tab);
if(window.chrome?.webview){window.chrome.webview.postMessage('character-name:'+encodeURIComponent(char?.name||''));window.chrome.webview.postMessage('resources:'+ (char?'v2|'+['hp','pp','rage','factor','spent','spe','karma'].map(k=>encodeURIComponent(Y.resourceCopy(char,k))).join('|'):'none'));}
}
function welcome(){return `<section class="welcome"><div><p class="eyebrow">LESS BOOKKEEPING. MORE ROLEPLAY.</p><h1>次の一手に、<br>集中しよう。</h1><p>キャラシートを読み込んで、セッションを開始。<br>行動の消費、変わり続けるステータス、対抗判定を<br>ひとつのボードで管理します。</p><div class="row wrap"><button class="primary" data-do="import">キャラシートを読み込む ↗</button><button data-do="demo">デモを試す</button><button data-do="restore-file">バックアップから復元</button><button data-do="manual">手動作成</button><a class="web-download download-primary" href="${WINDOWS_DOWNLOAD}" download="${WINDOWS_FILE}">Windows版をダウンロード ↓</a></div><p class="muted-small">対応：RW v0.3pre6.3形式の .xlsx<br>ファイルは端末内で処理されます。</p><p class="web-download download-note">Windows版はZIPを展開して起動できます。<br>HTML版とWindows版の保存データは別々です。バックアップから移せます。</p></div><div class="welcome-art">${symbol}<span class="art-label one">TOTAL PP <b>15</b> → 因子 <b>+3 Rd</b></span><span class="art-label two">あなたの冒険を、この場所に。</span></div></section><section class="welcome-list"><div><small>01 / IMPORT</small><h3>キャラクターを持ち込む</h3><p>ステータスと応用技をExcelから反映。複数キャラもいつでも切り替え。</p></div><div><small>02 / PLAN</small><h3>宣言する前に確かめる</h3><p>消費・活性・バフをまとめて計算。命中の勝率とダメージ期待値も比較。</p></div><div><small>03 / REWIND</small><h3>一手ずつ、記録する</h3><p>行動ごとの状態を保存。過去の記録を残したまま好きな地点に戻る。</p></div></section>`;}
function sessionHeader(char){const s=char.state;return `<div class="session-sticky">${characterStatus(char)}<div class="heading session-toolbar"><button data-do="condition">コンディション</button><button data-do="damage">被ダメージ</button><button data-do="pending" class="${s.pending?.length?'has-pending':''}">保留中の処理${s.pending?.length?'（'+s.pending.length+'）':''}</button><button data-do="adjust">状態を調整</button><button data-do="options" aria-label="オプション">⚙ オプション</button>${Y.isBattle(s)?`<button class="primary next-round" data-do="next-round">R${s.round+1} へ進む →</button>`:''}</div><nav class="tabs" aria-label="画面切替">${[['actions','行動を組み立てる'],['draft','宣言・期待値'],['buffs','盤面の補正'],['history','行動履歴'],['character','キャラクター']].map(([t,l])=>`<button class="${(tab===t||t==='draft'&&tab==='compare')?'active':''}" data-do="tab" data-tab="${t}">${l}${t==='history'?`<span class="count">${char.history.length}</span>`:t==='buffs'?`<span class="count">${s.buffs.filter(b=>b.active).length}</span>`:''}</button>`).join('')}</nav></div>`;}
function viewForTab(){return tab==='actions'?actionsView():['draft','compare'].includes(tab)?declarationView():tab==='buffs'?buffView():tab==='history'?historyView():characterView();}
function board(char){return `<div class="tab-content">${viewForTab()}</div>`;}
function actionCost(a){
 const unit=a.level?(a.consumable?' / 個':' / Lv'):'',uses=a.owned&&['SPE','カルマ','消費アイテム'].includes(a.group);
 const parts=[];if(a.ppMode==='creation'||a.replace!==undefined)parts.push(Y.costLabel(a));else if(a.pp)parts.push(a.pp+' PP'+unit);if(a.hp)parts.push('HP '+a.hp+unit);if(a.factor)parts.push(a.factor+' Rd'+unit);if(a.rage)parts.push('暴走 +'+a.rage+'%'+unit);
 const cost=a.variableCosts?.length||a.dynamicPP?esc(a.costText||'宣言時に決定'):parts.map(esc).join('・');
 if(uses)return `<b class="remaining-count">${esc(Y.ownedCountLabel(c(),a))}</b><span>${a.consumable?'各1回・使い切り':esc(a.limitText||'回数制限なし')}</span>${cost?'<span class="cost-exception">消費 '+cost+'</span>':''}`;
 return `<b>${cost||'消費なし'}</b>${a.pp&&!a.noRagePP?'<span>暴走 ＋PP消費分</span>':''}`;
}
function optionSummary(a){
 const uses=a.owned&&['SPE','カルマ','消費アイテム'].includes(a.group);
 const summary=uses?Y.ownedCountLabel(c(),a):Y.costLabel(a);
 return a.name+' — '+(a.spec<0?'常時圧迫 '+(-a.spec)+' SP':summary+(!uses&&a.spec?' / SP '+a.spec:''));
}
function actionDetails(a){
 const composition=Array.isArray(a.effects)?a.effects.join(' / '):'';
 let effect=a.note||'';
 if(a.group==='応用技'&&composition&&effect.startsWith(composition))effect=effect.slice(composition.length).replace(/^：/,'').trim();
 const skill=a.explorationSkill?(a.explorationSkill==='能力精度'?c().stats.precision:c().stats.skills[a.explorationSkill]):null;
 return `<div class="selection-detail"><div class="selection-heading"><b>${esc(a.name)}</b>${a.owned?`<button class="ghost small" data-do="inventory-edit" data-id="${esc(a.id)}">編集</button>`:''}</div><div class="selection-meta"><span>${actionCost(a)}</span>${!a.owned&&a.spec?`<span>${a.spec<0?'常時圧迫 '+(-a.spec)+' SP':'必要SP '+esc(a.spec)}</span>`:''}${skill!=null?`<span>技能の基礎値 ${esc(skill)}</span>`:''}</div>${composition?`<p><b>技構成</b> ${esc(composition)}</p>`:''}${effect?`<p><b>${a.group==='応用技'?'技効果':'効果・条件'}</b> ${esc(effect)}</p>`:''}</div>`;
}
function progressControls(){const s=c().state,battle=Y.isBattle(s);return `<div class="progress-controls"><div class="mode-switch" role="group" aria-label="進行モード"><button data-do="mode" data-mode="exploration" aria-pressed="${!battle}" class="${!battle?'active':''}">探索中</button><button data-do="mode" data-mode="battle" aria-pressed="${battle}" class="${battle?'active':''}">バトル中</button></div>${battle?`<div class="phase-bar">${Object.entries(Y.phases).filter(([k])=>k!=='EX').map(([k,v])=>`<button class="${s.phase===k?'active':''}" data-do="phase" data-phase="${k}" title="${v}">${k}<span style="display:block;font-size:10px">${v}</span></button>`).join('')}</div>`:''}</div>`;}
const categoryOrder=['基本行動','応用技','AE','バースト','特殊武装','SPE','カルマ','消費アイテム'];
const otherGroups=['SPE','カルマ','消費アイテム'];
const commandGroups=['基本行動','応用技・特殊武装','AE','バースト','死力','その他'];
const commandGroup=group=>otherGroups.includes(group)?'その他':['応用技','特殊武装'].includes(group)?'応用技・特殊武装':group;
function draftEntries(){const rank=a=>{const i=categoryOrder.indexOf(a.group);return i<0?categoryOrder.length:i;};return draft.map((r,i)=>({r,i})).sort((a,b)=>rank(a.r.action)-rank(b.r.action)||a.i-b.i);}

const actionInputs=new Map();
function commandValues(a){return actionInputs.get(c().id+':'+a.id)||{};}
function commandRow(a){
 const preferred=({RE:'dodge',EX:'skill',IN:'initiative'})[c().state.phase]||'hit';
 return {action:Y.clone(a),level:1,target:a.targets?.includes(preferred)?preferred:a.target||'hit',result:null,creationPP:null,chargeLevel:1,...commandValues(a)};
}
function commandReason(a){return draft.some(r=>Y.sameAction(r.action,a))?'追加済み':Y.available(c(),a,draft)||Y.declarationInputError(commandRow(a))||Y.ppBudget(c(),[...draft,commandRow(a)],desperate).error;}
function commandCost(a){const r=commandRow(a);if(Y.declarationInputError(r))return '宣言する値を入力してください';const parts=[],pp=Y.declaredPP(r,c().state);if(pp)parts.push(pp+' PP');if(a.hp)parts.push('HP '+a.hp*r.level);if(a.factor)parts.push(a.factor*r.level+' Rd');return (a.ppMode==='creation'?'固定 '+a.pp+' ＋ 創造 '+r.creationPP+' → ':'今回：')+(parts.join(' / ')||'消費なし');}
function trapInputs(r,attr){
 if(r.action.trapId)return '<p class="usage-note">設置済み／'+(r.action.trapStage==='activate'?'起動：SS命中':'解放：物理命中')+(r.action.trapTarget==='enemy'?'／命中・威力 +2D':'')+'</p>';
 return `<label>設置先<select ${attr('trapTarget')}><option value="">選択してください</option>${[['self','自身'],['ally','他者（味方）'],['enemy','他者（敵）'],['field','場']].map(([v,t])=>`<option value="${v}" ${r.trapTarget===v?'selected':''}>${t}</option>`).join('')}</select></label><label>対象名・場所<input type="text" ${attr('trapLabel')} value="${esc(r.trapLabel||'')}"></label><label>起動条件<input type="text" ${attr('trapTrigger')} value="${esc(r.trapTrigger||'')}" placeholder="空欄なら解放のみ"></label><label>設置結果<select ${attr('trapResult')}><option value="success">成功・設置済みとして保存</option><option value="miss" ${r.trapResult==='miss'?'selected':''}>失敗・コストのみ登録</option></select></label><p class="usage-note">敵への設置のみ物理命中判定。登録後は設置済みの候補から解放・起動を選べます。</p>`;
}
function pendingView(char){const pending=char.state.pending||[],traps=char.state.traps||[],actions=Y.trapActions(char);return `<div class="pending-body"><section><h3>未処理のロール・追加処理</h3>${pending.length?pending.map((text,i)=>`<div class="pending-entry"><strong>${esc(Y.pendingLabel(text))}</strong><button class="small" data-do="resolve-pending" data-index="${i}">結果を記録</button></div>`).join(''):'<p class="subtle">未処理の項目はありません。</p>'}<p class="usage-note">ダイスは卓上で振り、結果と増減を記録してください。選んだ項目だけを処理済みにします。</p></section><section><h3>設置済みトラップ</h3>${traps.length?traps.map(t=>`<article class="pending-trap"><b>${esc(t.source.name)}</b><dl><dt>設置先</dt><dd>${esc(t.label)}</dd><dt>起動条件</dt><dd>${esc(t.trigger||'指定なし（解放のみ）')}</dd></dl>${t.target==='enemy'?'<p class="usage-note">敵設置：解放・起動の命中／威力 +2D</p>':''}<div class="row wrap">${actions.filter(a=>a.trapId===t.id).map(a=>{const reason=commandReason(a);return `<button class="small" data-do="add-action" data-id="${esc(a.id)}" ${reason?'disabled':''} title="${esc(reason||'今回の宣言へ追加')}">${a.trapStage==='activate'?'起動（SS）':'解放（物理）'}${reason==='追加済み'?'・追加済み':''}</button>`;}).join('')}</div></article>`).join(''):'<p class="subtle">設置済みのトラップはありません。</p>'}<p class="usage-note">解放・起動は宣言へ追加します。「この宣言を登録」で使用済みになります。</p></section></div>`;}
function commandInputs(a){
 const r=commandRow(a),attr=field=>`data-command-field="${field}" data-action-id="${esc(a.id)}"`;
 const fields=[];
 if(Y.isTrap(a))fields.push(trapInputs(r,attr));
 if(a.level)fields.push(`<label>${a.consumable?'使用個数':'宣言Lv'}<input type="number" min="1" max="${Y.declarationLevelLimit(c(),[...draft,r],r,'level',desperate)}" step="1" ${attr('level')} value="${r.level??''}" aria-label="${esc(a.name)}の${a.consumable?'使用個数':'宣言レベル'}"></label>`);
 if(a.ppMode==='creation')fields.push(`<label>創造PP<select ${attr('creationPP')} aria-label="${esc(a.name)}の創造PP"><option value="">1〜10を選択</option>${Array.from({length:10},(_,i)=>`<option value="${i+1}" ${r.creationPP===i+1?'selected':''}>${i+1} PP</option>`).join('')}</select></label>`);
 if(Y.hasCharge(a))fields.push(`<label>チャージLv<input type="number" min="1" max="${Y.declarationLevelLimit(c(),[...draft,r],r,'chargeLevel',desperate)}" step="1" ${attr('chargeLevel')} value="${r.chargeLevel??''}" aria-label="${esc(a.name)}のチャージLv"></label><span class="usage-note">1Lvごとに2PPを先払い。チャージ完了時に、カウント×3Dを命中・威力へ加算します。</span>`);
 if(a.targets)fields.push(`<label>補正先<select ${attr('target')} aria-label="${esc(a.name)}の補正先">${a.targets.map(t=>`<option value="${t}" ${r.target===t?'selected':''}>${Y.labels[t]||({damage:'ダメージ',skill:'技能・解除'})[t]||t}</option>`).join('')}</select></label>`);
 return fields.length?`<div class="command-inputs">${fields.join('')}</div><p class="command-cost-summary" aria-live="polite">${esc(commandCost(a))}</p>`:'';
}
function updateCommandInput(el){
 const a=Y.allActions(c()).find(a=>a.id===el.dataset.actionId),field=el.dataset.commandField;if(!a||!['level','creationPP','chargeLevel','target','trapStage','trapTarget','trapLabel','trapTrigger','trapResult'].includes(field))return;
 actionInputs.set(c().id+':'+a.id,{...commandValues(a),[field]:['target','trapStage','trapTarget','trapLabel','trapTrigger','trapResult'].includes(field)?el.value:el.value===''?null:Number(el.value)});
 const card=el.closest('.action-command'),reason=commandReason(a),add=card.querySelector('[data-do="add-action"]');add.disabled=!!reason;add.textContent=reason==='追加済み'?'追加済み':'＋ 追加';card.querySelector('.picker-hint').textContent=reason;const cost=card.querySelector('.command-cost-summary');if(cost)cost.textContent=commandCost(a);const funding=card.querySelector('.funding-choice');if(funding)funding.innerHTML=fundingChoice(a);
}
function actionCommands(){
 const char=c(),all=Y.allActions(char).filter(a=>Y.phaseAllowed(a,char.state,draft));
 const groups=[...new Set([...commandGroups,...all.map(a=>commandGroup(a.group))])];
 return `<div class="action-command-grid">${groups.map((group,index)=>{
  if(group==='死力')return `<section class="action-command desperate-command" data-category="死力"><div class="command-label"><label for="desperate">死力</label></div><label>宣言Lv<input id="desperate" type="number" min="0" max="${Y.desperateLimit(char,draft)}" step="1" value="${desperate}"></label><p class="usage-note">上限 Lv${Y.desperateLimit(char,draft)}。1LvにつきHP2でPP1を代用（HP0まで可）。今回の合計消費PP以内。${desperate>Y.desperateLimit(char,draft)?'<strong class="error">上限を超えています</strong>':''}</p></section>`;
  const entries=all.filter(a=>commandGroup(a.group)===group&&Y.actionMatches(a,search)),selected=entries.find(a=>a.id===selectedActions[group]);
  const reason=selected?commandReason(selected):'';
  const option=a=>{const why=draft.some(r=>Y.sameAction(r.action,a))?'追加済み':Y.available(char,a,draft);return `<option value="${esc(a.id)}" ${a===selected?'selected':''}>${esc(optionSummary(a))}${why?'（'+esc(why)+'）':''}</option>`;};
  const options=['その他','応用技・特殊武装'].includes(group)?(group==='その他'?otherGroups:['応用技','特殊武装']).map(sub=>{const rows=entries.filter(a=>a.group===sub);return rows.length?`<optgroup label="${esc(sub)}">${rows.map(option).join('')}</optgroup>`:'';}).join(''):entries.map(option).join('');
  return `<section data-category="${esc(group)}" class="action-command ${selected?'has-selection':''}"><div class="command-label"><label for="command-${index}">${esc(group)}</label><span>${entries.length}件</span></div><div class="action-picker-row"><select id="command-${index}" data-action-pick="${esc(group)}" aria-label="${esc(group)}を選択" ${!entries.length?'disabled':''}><option value="">${entries.length?'選んでください':search?'一致する候補なし':'このフェイズの候補なし'}</option>${options}</select><button type="button" class="primary action-add" data-do="add-action" data-id="${esc(selected?.id||'')}" aria-label="${esc(group)}を宣言へ追加" ${!selected||reason?'disabled':''}>${reason==='追加済み'?'追加済み':'＋ 追加'}</button></div>${selected?commandInputs(selected):''}<p class="picker-hint" role="status">${esc(reason)}</p><div class="funding-choice">${selected?fundingChoice(selected):''}</div>${selected?actionDetails(selected):''}</section>`;
 }).join('')}</div>`;
}
function chargeStatus(){const q=c().state.charge;return q?`<div class="charge-status"><span><b>${esc(q.source.name)}</b>　チャージ ${q.count} / ${q.level}　命中・威力 +${3*q.count}D</span><button type="button" class="small ghost" data-do="cancel-charge">チャージ解除</button></div>`:'';}
function techniqueBonusView(row,index){
 const b=Y.techniqueBonuses(c(),row,draft);if(!b.items.length&&!b.notes.length)return '';
 return `<div class="technique-bonuses"><b>補正量（自動計算）</b>${b.items.length?`<span class="usage-note">能力精度 ${b.precision} ／ 3分の1切捨て ${b.unit}</span><div class="bonus-chips">${b.items.map(x=>`<span>${esc(x.kind+'・'+x.label)} <strong>${x.dice?'+'+x.dice+'D':(x.flat>=0?'+':'')+x.flat}</strong>${x.count>1?'（'+x.count+'重）':''}</span>`).join('')}</div>`:''}${b.notes.map(n=>`<p class="usage-note">${esc(n)}</p>`).join('')}${b.items.length&&!Y.hasCharge(row.action)?`<button class="small" type="button" data-do="buff-from-technique" data-index="${index}">盤面の補正へ登録</button>`:''}</div>`;
}
function fundingChoice(a){
 const r=commandRow(a);if(draft.some(x=>Y.sameAction(x.action,a))||Y.available(c(),a,draft)||Y.declarationInputError(r))return '';
 const b=Y.ppBudget(c(),[...draft,r],desperate);return b.error&&b.canFund?`<button type="button" class="small" data-do="add-funded" data-id="${esc(a.id)}">死力Lv${b.required}で追加（合計HP${2*b.required}消費）</button>`:'';
}
function explorationView(){
 const v=Y.explorationInputs(c(),compareOpts.includeDraft?draft:[]),label=v.key?(v.key.startsWith('skill:')?v.key.slice(6):Y.labels[v.key]):'';
 return `<div class="panel compact-compare exploration-compare"><div class="panel-head"><h2>勝率</h2>${label?'<button class="small ghost" data-do="reset-exploration">宣言から自分を反映</button>':''}</div><p class="usage-note">${label?'自分：'+esc(label)+(v.manual?'（手入力で調整）':'（宣言の補正込み）'):'自分の固定値・ダイス数を入力してください。'}　目標が固定値ならダイス数を0にします。</p><div class="exploration-values"><fieldset><legend>自分</legend>${input('explore-ownFixed','固定値',v.ownFixed??'')}${input('explore-ownDice','ダイス数',v.ownDice??'','number','min="0" max="100"')}</fieldset><fieldset><legend>目標・相手</legend>${input('explore-targetFixed','固定値',v.targetFixed)}${input('explore-targetDice','ダイス数',v.targetDice,'number','min="0" max="100"')}</fieldset></div><p id="effective-own" class="usage-note"></p><div id="comparison-results"></div><details class="compare-extra"><summary>計算条件</summary><div class="form-grid two">${select('compare-mode','自分・相手のダイス',compareOpts.mode,[['cf','クリティカル・ファンブルあり'],['normal','通常のD6']])}${select('compare-exploreTie','同値の扱い',compareOpts.exploreTie||'auto',[['auto','固定目標は成功／対抗は同値ロール'],['attacker','成功'],['defender','失敗'],['reroll','同値ロール（50%）']])}</div></details></div>`;
}
function calculateExploration(){
 const v=Y.explorationInputs(c(),compareOpts.includeDraft?draft:[]);$('#effective-own').textContent='';
 try{
  if(![v.ownFixed,v.ownDice,v.targetFixed,v.targetDice].every(Number.isInteger))throw Error('固定値とダイス数を整数で入力してください。');
  const tie=compareOpts.exploreTie&&compareOpts.exploreTie!=='auto'?compareOpts.exploreTie:v.targetDice===0?'attacker':'reroll';
  const r=Y.compare({ownFixed:v.ownFixed,ownDice:v.ownDice,enemyFixed:v.targetFixed,enemyDice:v.targetDice,mode:compareOpts.mode,tie});
  $('#effective-own').textContent=`自分 ${v.ownFixed} + ${v.ownDice}D ／ 目標 ${v.targetFixed} + ${v.targetDice}D`;
  $('#comparison-results').innerHTML=`<div class="result-grid check-only"><div class="result primary-result"><div class="result-label">${v.targetDice===0?'成功率':'勝率'}</div><div class="result-number">${(r.win*100).toFixed(1)}<small>%</small></div><div class="result-caption">同値は${tie==='attacker'?'成功':tie==='defender'?'失敗':'同値ロール（50%）'}</div></div><div class="result"><div class="result-label">達成値の期待値</div><div class="result-number">${r.ownMean.toFixed(2)}</div><div class="result-caption">目標・相手 ${r.enemyMean.toFixed(2)}</div></div></div>`;
 }catch(e){$('#comparison-results').innerHTML=`<div class="error">${esc(e.message)}</div>`;}
}
function wheelSelect(e){
 const el=e.target.closest?.('select');if(!el||el.disabled||el.multiple||e.ctrlKey||!e.deltaY)return;
 e.preventDefault();e.stopPropagation();
 const delta=e.deltaY*(e.deltaMode===1?20:e.deltaMode===2?400:1),old=wheelAmounts.get(el)||0,total=Math.sign(old)===Math.sign(delta)?old+delta:delta;
 wheelAmounts.set(el,total);if(Math.abs(total)<40)return;wheelAmounts.set(el,0);
 const step=Math.sign(total),options=Array.from(el.options);let next=el.selectedIndex+step;
 while(next>=0&&next<options.length&&(options[next].disabled||options[next].parentElement?.disabled))next+=step;
 if(next<0||next>=options.length)return;el.selectedIndex=next;
 el.dispatchEvent(new el.ownerDocument.defaultView.Event('change',{bubbles:true}));
}

function actionsView(){
 const char=c(),state=char.state,battle=Y.isBattle(state);
 return `<div class="workspace action-workspace"><section class="panel action-panel"><div class="panel-head"><div><h2>${battle?'このラウンドの行動':'探索中の行動'}</h2><p class="subtle">種類ごとに選んで、宣言へ追加</p></div><span class="tag">${battle?'ROUND '+state.round.toString().padStart(2,'0'):'EXPLORATION'}</span></div>${progressControls()}${chargeStatus()}<p class="usage-note spec-status">使用可能SP <b>${Y.effective(char,'spec').fixed}</b>${Y.specPressure(char)?' ／ 応用技の常時圧迫 '+Y.specPressure(char)+' SP':''}</p><div class="action-picker"><label for="action-search">候補を検索<input class="search" id="action-search" type="search" placeholder="技名・効果・分類で候補を絞る" value="${esc(search)}"></label>${actionCommands()}</div><div class="row wrap inventory-tools"><button class="small" data-do="inventory-add">＋ 所持品</button><button class="ghost small" data-do="custom-action">＋ カスタム行動</button></div><p class="usage-note">${state.phase==='EN'?'オート・セミオート・トラップの応用技は暫定候補です。発動条件を確認してください。<br>':''}SP＝必要スペック。負のSPは常時圧迫として反映。同じAE・応用技は1つの宣言に1回まで。</p></section>${draftView(true)}</div>`;
}
function draftTotals(p){
 const s=c().state,sign=n=>(n>0?'+':'')+n;
 const changes=[['HP消費',p.hp,'−'+p.hp],['PP消費',p.pp,'−'+p.pp],['因子消費',p.factor,'−'+p.factor+' Rd'],['暴走率',p.after.rage-s.rage,sign(p.after.rage-s.rage)+'%'],['総消費PP',p.spent,sign(p.spent)],['HP回復',Math.max(0,p.after.hp-(s.hp-p.hp)),sign(Math.max(0,p.after.hp-(s.hp-p.hp)))],['PP回復',Math.max(0,p.after.pp-(s.pp-p.pp)),sign(Math.max(0,p.after.pp-(s.pp-p.pp)))],['総消費PPによる因子獲得',p.gained,'+'+p.gained+' Rd']].filter(([,v])=>v!==0);
 const after=['hp','pp','rage','factor','spent'].filter(k=>p.after[k]!==s[k]).map(k=>Y.labels[k]+' '+p.after[k]+(k==='rage'?'%':k==='factor'?' Rd':''));
 return (changes.length?'<div class="draft-totals">'+changes.map(([label,,value])=>'<div><span>'+label+'</span><b>'+value+'</b></div>').join('')+'</div>':'')+(draft.length&&after.length?'<div class="next-state">登録後　'+after.join(' / ')+'</div>':'');
}
function draftChecks(){
 const keys=Y.declarationKeys(Y.resolveDeclarationRows(c(),draft));if(!keys.length)return '<div class="draft-checks"><b>判定式</b><p class="usage-note">判定を伴う行動を追加すると、関連する項目を表示します。</p></div>';
 return `<details class="draft-checks" open><summary>判定式・行動値（今回の宣言を反映）</summary><div class="check-formulas">${keys.map(key=>{const v=Y.declaredValue(c(),key,draft),label=key.startsWith('skill:')?key.slice(6):Y.labels[key],damage=['melee','weapon','power'].includes(key);let formula=v.dice?v.fixed+' + '+v.dice+'D6':String(v.fixed);if(damage&&draft.some(r=>['mercy','squeeze'].includes(r.action.id)))formula='('+formula+') ÷ 2';return `<div><span>${esc(label)}${damage?'ダメージ':''}</span><code>${esc(formula)}</code></div>`;}).join('')}</div><p class="usage-note">現在のBP・活性・盤面補正と、宣言内のコンセ・ブースト等を反映。個別の技効果は盤面の補正へ登録してください。判定式は消費前の状態です。</p></details>`;
}
function draftView(provisional=false){const p=Y.preview(c(),draft,desperate);return `<aside class="panel draft"><div class="draft-header"><div class="row between"><h2>${provisional?'宣言一覧（暫定）':'今回の宣言'} <span class="draft-count">${draft.length.toString().padStart(2,'0')}</span></h2><div class="row draft-header-tools">${provisional?'':`<button type="button" class="primary draft-register" data-do="commit" ${!draft.length||p.errors.length?'disabled':''}>この宣言を登録</button><button type="button" class="draft-copy" data-do="copy-draft" ${!draft.length?'disabled':''}>宣言をコピー</button>`}<button class="draft-expand" data-do="tab" data-tab="${['draft','compare'].includes(tab)?'actions':'draft'}">${['draft','compare'].includes(tab)?'行動一覧へ':'宣言・期待値へ ↗'}</button></div></div><p class="subtle">組み合わせと消費を確認してから登録</p></div><div class="draft-body">${chargeStatus()}${draftChecks()}${draft.length?draftEntries().map(({r,i})=>`<div class="draft-row" data-category="${esc(r.action.group)}"><span class="draft-category">${esc(r.action.group)}</span><div class="row between"><button type="button" class="draft-action-copy" data-do="copy-draft-action" data-index="${i}" title="この行動をコピー"><b>${esc(r.action.name)}</b><span aria-hidden="true"> ⧉</span></button><button class="ghost small" data-do="remove-draft" data-index="${i}" aria-label="${esc(r.action.name)}を外す">×</button></div><p class="muted-small">${esc(r.action.note)}</p>${techniqueBonusView(r,i)}${Y.hasCharge(r.action)?`<p class="usage-note">チャージLv${r.chargeLevel??1}：完了時に命中・威力 +${3*(r.chargeLevel??1)}D</p>`:''}<div class="mini-fields">${Y.isTrap(r.action)?trapInputs(r,field=>`data-draft="${field}" data-index="${i}"`):''}${r.action.ppMode==='creation'?`<label>創造PP（宣言ごとに選択）<select data-draft="creationPP" data-index="${i}" aria-label="${esc(r.action.name)}の創造PP"><option value="">1〜10から選択</option>${Array.from({length:10},(_,n)=>`<option value="${n+1}" ${r.creationPP===n+1?'selected':''}>${n+1} PP</option>`).join('')}</select></label><p class="usage-note">固定追加 ${r.action.pp}PP ＋ 創造 ${r.creationPP??'未選択'}PP${r.creationPP!=null?' ＝ この技の消費 '+Y.declaredPP(r,c().state)+'PP':''}</p>`:''}${Y.hasCharge(r.action)?`<label>チャージLv<input type="number" min="1" max="${Y.declarationLevelLimit(c(),draft,r,'chargeLevel',desperate)}" step="1" data-draft="chargeLevel" data-index="${i}" value="${r.chargeLevel===undefined?1:r.chargeLevel??''}"></label>`:''}${r.action.itemTarget?`<label>使用対象<select data-draft="itemTarget" data-index="${i}"><option value="self" ${r.itemTarget!=='other'?'selected':''}>自分（回復を自動反映）</option><option value="other" ${r.itemTarget==='other'?'selected':''}>他者（自身は回復しない）</option></select></label>`:''}${(r.action.variableCosts||[]).map(k=>`<label>今回の${Y.labels[k]}消費${k==='factor'?'（Rd）':''}<input type="number" min="0" data-draft="owned-${k}" data-index="${i}" value="${r['owned-'+k]??''}" placeholder="0以上"></label>`).join('')}${r.action.level?`<label>${r.action.consumable?'使用個数':'Lv'}<input type="number" data-draft="level" data-index="${i}" min="1" max="${Y.declarationLevelLimit(c(),draft,r,'level',desperate)}" value="${r.level}"></label>`:''}${r.action.targets?`<label>補正先<select data-draft="target" data-index="${i}">${r.action.targets.map(t=>`<option value="${t}" ${r.target===t?'selected':''}>${Y.labels[t]||({damage:'ダメージ',skill:'技能・解除'})[t]}</option>`).join('')}</select></label>`:''}${r.action.roll&&r.itemTarget!=='other'?`<label>${r.action.rollDice*r.level}D6の出目<input type="number" data-draft="result" data-index="${i}" value="${r.result??''}" min="${r.action.rollDice*r.level}" max="${6*r.action.rollDice*r.level}" placeholder="実際の合計"></label><button class="small" data-do="roll" data-index="${i}" title="ランダムな実際の出目を入力">振る</button>`:''}</div></div>`).join(''):'<div class="empty-draft"><span class="plus">＋</span>行動一覧から行動を選ぶと、<br>ここで組み合わせを確認できます。</div>'}${draft.length?'<p class="pp-budget">実消費PP '+p.pp+' / 現在PP '+c().state.pp+(desperate?'（死力Lv'+desperate+'反映）':'')+'</p>':''}${draftTotals(p)}${draft.length&&p.errors.length?`<div class="error">${p.errors.map(esc).join('<br>')}</div>`:''}${draft.length&&p.warnings.length?`<div class="warning">${p.warnings.map(esc).join('<br>')}</div>`:''}${provisional?'':`<label style="margin-top:15px">行動メモ<textarea id="action-note" placeholder="対象・宣言・判定結果など">${esc(note)}</textarea></label>`}</div>${provisional?'':'<div class="draft-footer"><p class="subtle">登録した状態は、履歴から巻き戻せます。</p></div>'}</aside>`;}
function declarationView(){return '<div class="declaration-comparison">'+progressControls()+draftView()+compareView()+'</div>';}

function comparison(){return Y.comparisonContext(Y.resolveDeclarationRows(c(),draft),compareOpts.selection||'auto');}
function compareView(){if(!Y.isBattle(c().state))return explorationView();const char=c(),o=char.state.opponent,cmp=comparison(),check=Y.opponentCheck(o,cmp.enemyKey);return `<div class="panel compact-compare"><div class="panel-head"><h2>勝率</h2><button class="small ghost" data-do="opponent-from-character">保存キャラから反映</button></div><div class="compare-choices">${select('compare-selection','比較する判定',compareOpts.selection||'auto',[['auto','宣言から自動選択'],['melee','格闘：命中 対 回避'],['weapon','武器：命中 対 回避'],['power','能力：命中 対 回避'],['mental','精神攻撃：SS 対 SS'],['dodge','通常回避：回避 対 命中'],['sense','精神回避：SS 対 SS']])}<span class="usage-note">${cmp.ready?(cmp.inferred?'自動：':'')+'自分の'+Y.labels[cmp.ownKey]+' 対 相手の'+Y.labels[cmp.enemyKey]:'攻撃・回避を宣言すると自動選択します'}</span></div>${document.getElementById('lycoris-integration')?'<div id="lyc-opponent-picker"><button type="button" data-lyc-opponent="scan">リコリスの相手コマを選ぶ</button></div>':''}<div class="compare-main-fields">${input('enemy-name','相手',o.name,'text')}${input('enemy-fixed','相手'+Y.labels[cmp.enemyKey],check.fixed??'')}${input('enemy-dice','相手'+Y.labels[cmp.enemyKey]+' D6',check.dice??'','number','min="0" max="20"')}${input(cmp.mental?'enemy-resist':'enemy-defense',cmp.mental?'抵抗力':'防御力',cmp.mental?o.resist:o.defense)}</div><div class="compare-switches"><label class="checkbox"><input type="checkbox" name="compare-includeDraft" ${compareOpts.includeDraft?'checked':''}>宣言の補正を反映</label><label class="checkbox"><input type="checkbox" name="compare-ignoreArmor" ${compareOpts.ignoreArmor?'checked':''}>装甲無視</label></div><p class="usage-note" id="effective-own"></p><div id="comparison-results"></div><details class="compare-extra"><summary>追加補正・相手の活性</summary><div class="form-grid two">${input('compare-ownFixed','自分の判定：追加固定値',compareOpts.ownFixed||0)}${input('compare-ownDice','自分の判定：追加D6',compareOpts.ownDice||0)}${input('enemy-hp','相手HP',o.hp)}${input(cmp.mental?'enemy-defense':'enemy-resist',cmp.mental?'相手の防御力':'相手の抵抗力',cmp.mental?o.defense:o.resist)}${select('enemy-activation','相手の活性',o.activation||'－',['－','覚醒型','増強型','反応型','感覚型','回復型'])}${input('enemy-rage','相手暴走率',o.rage||0,'number','min="0"')}</div><p class="usage-note">相手の判定値はBP・活性込み。増強型の被ダメージ軽減は活性と暴走率から別計算し、装甲無視でも適用します。</p></details><details class="about"><summary>計算条件と詳細</summary><div class="form-grid" style="margin:15px 0">${select('compare-mode','判定ダイス',compareOpts.mode,[['cf','クリティカル・ファンブルあり'],['normal','通常のD6（特殊処理なし）']])}${select('compare-tie','同値の場合',compareOpts.tie,[['reroll','同値ロール（勝率50%）'],['attacker','攻撃側優先'],['defender','防御側優先']])}${select('compare-minimum','装甲適用後の下限',compareOpts.minimum,[[0,'0ダメージ'],[1,'1ダメージ']])}</div><p>最初の6は連続する限り追加、最初の1は1D6減算。最終達成値の下限は1です。ダメージは通常D6で、倍差命中とスマッシュクリティカルを含みます。勝率・期待値は分布計算で求めています（極小の無限尾部のみ打切り）。</p><p>1回の対抗判定・単体への1ヒットが対象です。戦闘全体の勝利確率、幸運系・特殊な出目操作、多段攻撃、トラップ等の独自処理は含みません。増強型はダメージ判定を軽減（下限1）、その後に装甲を適用します。装甲適用後の下限は卓に合わせて変更できます。</p></details></div>`;}
function calculate(){if(!Y.isBattle(c().state)){calculateExploration();return;}try{const char=c(),cmp=comparison(),rows=compareOpts.includeDraft?draft:[],own=Y.declaredValue(char,cmp.ownKey,rows,{fixed:compareOpts.ownFixed,dice:compareOpts.ownDice}),atk=cmp.attack?Y.declaredValue(char,cmp.attack,rows):{fixed:0,dice:0},o=char.state.opponent,check=Y.opponentCheck(o,cmp.enemyKey),half=rows.some(r=>['mercy','squeeze'].includes(r.action.id));
 $('#effective-own').textContent='';
 if(!cmp.ready){$('#comparison-results').innerHTML='<p class="usage-note">攻撃・回避を宣言するか、比較する判定を選んでください。</p>';return;}
 const ownFormula=`自分の${Y.labels[cmp.ownKey]}：${own.fixed} + ${own.dice}D6`,enemyLabel='相手の'+Y.labels[cmp.enemyKey];
 $('#effective-own').textContent=ownFormula+' ／ '+enemyLabel+'：'+(check.fixed===null||check.dice===null?'未入力':check.fixed+' + '+check.dice+'D6');
 if(!Number.isSafeInteger(check.fixed)||!Number.isInteger(check.dice))throw Error(enemyLabel+'の固定値・ダイス数を入力するか、相手コマから読み込んでください。');
 const em=Y.modifiers(char,cmp.enemyKey,'enemy'),am=Y.modifiers(char,cmp.mental?'resist':'defense','enemy');const ef=Math.floor((check.fixed+em.flat)*em.mult),ed=Math.max(0,check.dice+em.dice),armor=compareOpts.ignoreArmor?0:Math.floor(((cmp.mental?o.resist:o.defense)+am.flat)*am.mult),reduction=Y.damageReduction({activation:o.activation,state:{rage:o.rage||0}});
 if(atk.dice<0||atk.dice>300)throw Error('ダメージダイスは0〜300の範囲にしてください');
 const tie=cmp.defending?({attacker:'defender',defender:'attacker'})[compareOpts.tie]||compareOpts.tie:compareOpts.tie;
 const result=Y.compare({ownFixed:own.fixed,ownDice:own.dice,enemyFixed:ef,enemyDice:ed,damageDice:atk.dice,damageFlat:atk.fixed,armor,reduction,mode:compareOpts.mode,tie,half,minimum:Number(compareOpts.minimum)});
 $('#effective-own').textContent=ownFormula+` ／ ${enemyLabel}：${ef} + ${ed}D6`+(cmp.attack?` ／ 威力 ${atk.dice}D6 + ${atk.fixed}・相手装甲 ${armor}・増強軽減 ${reduction}`:'');
 const lower=Math.max(1,Math.floor(Math.min(result.ownMean,result.enemyMean)-12)),upper=Math.ceil(Math.max(result.ownMean,result.enemyMean)+20),bins=Math.min(35,upper-lower+1),step=Math.ceil((upper-lower+1)/bins);let bars=[];for(let i=lower;i<=upper;i+=step){let a=0,b=0;for(let j=i;j<i+step;j++){a+=result.own.get(j)||0;b+=result.enemy.get(j)||0;}bars.push({x:i,a,b});}const peak=Math.max(...bars.flatMap(b=>[b.a,b.b]),.01);
 $('#comparison-results').innerHTML=`<div class="result-grid"><div class="result primary-result"><div class="result-label">${cmp.defending?'回避成功率':'対抗判定の勝率'}</div><div class="result-number">${(result.win*100).toFixed(1)}<small>%</small></div><div class="result-caption">同値 ${(result.equal*100).toFixed(1)}% ／ ${cmp.defending?'倍差回避':'倍差命中'} ${(result.double*100).toFixed(1)}%</div></div>${cmp.attack?`<div class="result"><div class="result-label">期待ダメージ</div><div class="result-number">${result.win>0?result.onHit.toFixed(1):'—'}<small>点</small></div><div class="result-caption">${result.win>0?'命中時の平均／装甲・増強軽減・倍差込み':'命中率0%のため算出対象外'}</div></div>`:''}<div class="result"><div class="result-label">達成値の期待値</div><div class="result-number">${result.ownMean.toFixed(2)}</div><div class="result-caption">相手 ${result.enemyMean.toFixed(2)} ／ 差 ${(result.ownMean-result.enemyMean).toFixed(2)}</div></div></div><details class="distribution"><summary>達成値の分布</summary><div class="row between"><h3>達成値の分布</h3><div class="legend"><span><i></i>自分</span><span><i class="enemy"></i>相手</span></div></div><div class="chart-wrap"><div class="chart" role="img" aria-label="自分と相手の達成値の確率分布">${bars.map((b,i)=>`<div class="chart-col" title="達成値${b.x}${step>1?'〜'+(b.x+step-1):''}：自分${(b.a*100).toFixed(2)}%、相手${(b.b*100).toFixed(2)}%"><i style="height:${b.a/peak*100}%"></i><i class="enemy" style="height:${b.b/peak*100}%"></i>${i%5===0?`<span>${b.x}</span>`:''}</div>`).join('')}</div></div><p class="muted-small">グラフは分布の中心部分を表示。確率計算は表示範囲外も含みます。</p></details>`;
 }catch(e){$('#comparison-results').innerHTML=`<div class="error">${esc(e.message)}</div>`;}}
function buffView(){const char=c();return `<div class="panel"><div class="panel-head"><div><h2>盤面のバフ・デバフ</h2><p class="subtle">名前、対象、補正値を登録。チェックを外すと一時的に無効になります。</p></div><button class="primary" data-do="add-buff">＋ 補正を追加</button></div>${char.state.buffs.length?char.state.buffs.map(b=>`<div class="buff-row ${b.active===false?'inactive':''}"><input type="checkbox" data-buff-toggle="${esc(b.id)}" ${b.active!==false?'checked':''} aria-label="${esc(b.name)}の有効切替"><div><b>${esc(b.name)}</b><small>${({self:'自分',enemy:'相手',both:'両者'})[b.target]} / ${(b.effects||[b]).length}項目${b.endRound?' / R'+b.endRound+'まで':''}</small></div><div class="buff-mod">${buffEffectsLabel(b)}</div><button class="small" data-do="edit-buff" data-id="${esc(b.id)}">編集</button></div>`).join(''):'<div class="empty">盤面の補正はまだありません。<br>味方からの支援や、相手のデバフを追加できます。</div>'}<p class="usage-note">同じステータスへの固定値・ダイス補正は加算、倍率は乗算して最後に切り捨てます。上書きルールで重ならない効果は、片方を無効にしてください。</p></div>`;}
function historyView(){const char=c();return `<div class="panel-head"><div><h2>行動履歴</h2><p class="subtle">巻き戻しもひとつの履歴として残ります。元の記録は消えません。</p></div><div class="row"><button class="small" data-do="export-history">CSV書出</button><button class="small" data-do="rollback" data-id="initial">読込時へ戻る</button></div></div>${[...char.history].reverse().map(e=>`<article class="history-entry"><header><div><div class="history-meta">${e.phase==='EX'?'探索中':'ROUND '+e.round+' / '+(Y.phases[e.phase]||e.phase)}　${new Date(e.time).toLocaleString('ja-JP')}</div><h3>${esc(e.title)}</h3></div><button class="small" data-do="rollback" data-id="${esc(e.id)}">この時点へ戻る</button></header><div class="history-chips">${['hp','pp','rage','factor','spent'].map(k=>`<span>${Y.labels[k]} ${e.before[k]} → <b>${e.after[k]}</b></span>`).join('')}</div>${e.detail?.rows?.some(r=>r.action.ppMode==='creation')?`<p class="usage-note">${e.detail.rows.filter(r=>r.action.ppMode==='creation').map(r=>esc(r.action.name)+'：創造 '+r.creationPP+'PP ＋ 固定追加 '+r.action.pp+'PP ＝ '+r.declaredPP+'PP').join('<br>')}</p>`:''}${e.detail?.spent!==undefined?`<p class="usage-note">消費PP ${e.detail.pp} / 総消費加算 ${e.detail.spent} / 獲得因子 +${e.detail.gained} Rd${e.detail.desperate?' / 死力 Lv'+e.detail.desperate:''}</p>`:''}${e.type==='damage'?`<p class="usage-note">判定 ${e.detail.raw} ／ 増強軽減 ${e.detail.reduction} ／ 装甲 ${e.detail.armor} → 被ダメージ ${e.detail.damage}</p>`:''}${e.detail?.note?`<p class="usage-note">${esc(e.detail.note)}</p>`:''}<details><summary>補正・相手を含む状態を見る</summary><pre>${esc(JSON.stringify(e.after,null,2))}</pre></details></article>`).join('')||'<div class="panel empty">登録した行動がここに並びます。</div>'}`;}
function characterView(){const char=c();return `<div class="panel"><div class="panel-head"><div><h2>キャラクター設定</h2><p class="subtle">読込元：${esc(char.source)}${char.importedAt?' / '+new Date(char.importedAt).toLocaleDateString('ja-JP'):''}</p></div><div class="row wrap">${firefoxMode?'<button class="primary" data-do="create-token">リコリスの盤面へ追加</button>':''}<button class="${firefoxMode?'small':'primary'}" data-do="export-token">コマZIPを書き出す</button><button data-do="edit-character">基礎ステータスを編集</button></div></div>${firefoxMode?'<p id="token-result" class="usage-note" role="status" aria-live="polite">選択中のリコリスへ、現在のキャラを新しいコマとして追加します。</p>':''}<label>情報（リコリスの自由記入欄）<textarea id="campaign-info">${esc(char.state.info||'')}</textarea></label><div class="stats-grid">${['hit','dodge','ss','melee','weapon','power','defense','resist','initiative','precision','spec'].map(k=>{const v=Y.effective(char,k);return `<div class="stat">${Y.labels[k]}<strong>${['melee','weapon','power'].includes(k)?v.dice+'D6 + '+v.fixed:['hit','dodge','ss'].includes(k)?v.fixed+' + '+v.dice+'D6':v.fixed}</strong></div>`}).join('')}</div><p class="usage-note">上記はBP・活性・盤面の補正を反映した値です。SSの補正は命中・回避判定用です。増強型の被ダメージ軽減：${Y.damageReduction(char)}点（装甲無視にも適用）。</p><div class="notice"><b>Better Parameter ${Y.bpConfig(char.state).enabled?'ON':'OFF'}</b><p class="usage-note">${bpSummary(char)}</p></div><hr class="section-divider"><div class="panel-head"><h3>応用技・カスタム行動</h3><button class="small" data-do="custom-action">＋ 登録</button></div>${char.actions.filter(a=>!a.owned).map(a=>`<div class="buff-row"><span class="tag">技</span><div><b>${esc(a.name)}</b><small>${esc(a.note)}</small></div><div class="buff-mod">${Y.costLabel(a)}${a.spec?' / '+a.spec+' spec':''}</div><button class="small" data-do="edit-action" data-id="${esc(a.id)}">編集</button></div>`).join('')||'<p class="subtle">応用技が未登録です。Excelから読み込むか、手動で登録できます。</p>'}<hr class="section-divider">${inventorySection()}<hr class="section-divider"><div class="row wrap"><button data-do="import">別のキャラシートを読込</button><button data-do="export">全データをバックアップ</button><button data-do="restore-file">バックアップを復元</button><button class="danger" data-do="delete-character">このキャラを削除</button></div></div>`;}
function importDialog(){modal('キャラシートを読み込む',`<p class="subtle" style="margin-bottom:18px">Excelのステータス・応用技・特殊武装・SPE・カルマ・消費アイテムをまとめて取り込み、キャラクターとして保存します。</p>${select('import-mode','開始する状態',importMode,[['progress','進行表の現在値を引き継ぐ'],['base','キャラシートの基礎値から開始']])}<p class="usage-note">対応形式：characterheet_RW_v0.3pre6.3.xlsxと同じセル配置。数式はExcelの保存済み計算結果を使います。取り込み前にExcelで再計算して保存してください。</p><div class="form-actions"><button data-do="manual">手動で作成</button><button class="primary" data-do="choose-xlsx">.xlsx ファイルを選ぶ</button></div>`);}
function importSummary(char){
 const groups=['応用技',...Y.ownedGroups];
 const lines=groups.map(g=>{const entries=char.actions.filter(a=>a.group===g);return g+' '+entries.length+'件'+(entries.length?'（'+entries.map(a=>esc(a.name)).join('、')+'）':'');});
 const pressure=Y.specPressure(char);
 if(pressure)lines.push('応用技の常時圧迫 '+pressure+' SP ／ 使用可能SP '+Y.effective(char,'spec').fixed+(char.specImport?.pressureIncluded?'（Excel反映済みの圧迫を二重に引きません）':''));
 return lines.join('<br>');
}
function importReview(char){const missing=char.actions.flatMap((a,i)=>(a.importMissing||[]).map(m=>({a,i,m})));if(!missing.length)return '';return `<hr class="section-divider"><h3>応用技の数値を確認</h3><div class="warning">ステータスは読み込めています。次の欄だけ数値を取得できませんでした。技の消費・スペックを入力すると保存できます。</div><div class="form-grid two">${missing.map(({a,i,m})=>input('import-action-'+i+'-'+m.field,esc(a.name)+'：'+(m.field==='pp'?(a.ppMode==='creation'?'固定追加PP（創造1〜10PPを除く）':'消費PP'):'必要スペック')+'（'+esc(m.cell)+'）','','number',(m.field==='pp'?'min="0" ':'')+'required')+`<p class="usage-note">Excel内の値：${esc(m.raw===''?'未保存・空欄':m.raw)}</p>`).join('')}</div>`;}
function characterDialog(char,isNew=false){pendingImport=isNew?char:null;const s=char.stats;modal(isNew?'読み込み内容を確認':'基礎ステータスを編集',`<form id="character-form"><div class="form-grid">${input('name','キャラクター名',char.name,'text','required')}${select('activation','活性タイプ',char.activation,['－','覚醒型','増強型','反応型','感覚型','回復型'])}${input('hpMax','基礎最大HP',s.hpMax,'number','min="1" required')}${input('ppMax','基礎最大PP',s.ppMax,'number','min="0" required')}${input('initiative','行動値',s.initiative)}${['hit','dodge','ss'].map(k=>input(k,Y.labels[k]+'固定値',s[k])+input(k+'Dice',Y.labels[k]+'ダイス',s[k+'Dice'],'number','min="0" max="20"')).join('')}${['melee','weapon','power'].map(k=>input(k,Y.labels[k]+'ダイス',s[k],'number','min="0" max="30"')+input(k+'Flat',Y.labels[k]+'固定値',s[k+'Flat'])).join('')}${['defense','resist','precision','spec'].map(k=>input(k,k==='spec'?'スペック（応用技の常時圧迫前）':Y.labels[k],s[k])).join('')}</div>${bpFields(char)}<details style="margin-top:18px"><summary>パラメータ・技能</summary><div class="form-grid four" style="margin-top:12px">${['筋力','耐久','知力','精神','器用','敏捷','運'].map((x,i)=>input('param'+i,x,s.params[i])).join('')}${Y.skillNames.map(x=>input('skill-'+x,x,s.skills[x]||0)).join('')}</div></details>${isNew?`<hr class="section-divider"><h3>引き継ぐ現在値</h3><div class="form-grid">${['hp','pp','rage','factor','spent','hpMax','ppMax'].map(k=>input('state-'+k,k==='hpMax'?'セッション最大HP':k==='ppMax'?'セッション最大PP':Y.labels[k],char.state[k])).join('')}</div>${importReview(char)}<p class="usage-note">${importSummary(char)}既存キャラは上書きせず、新しいキャラとして追加します。</p>`:'<p class="usage-note">現在HP・PPは「状態を調整」で変更できます。基礎設定の編集は過去の状態スナップショットには影響しません。</p>'}<p class="usage-note">反応型はSSを用いる命中・回避判定にも加算。感覚型は行動値に加算。増強型は防御力を増やさず、「被ダメージ」と期待ダメージで軽減します。</p><div class="form-actions"><button type="button" data-do="close">キャンセル</button><button class="primary" type="submit">${isNew?'このキャラを保存':'設定を保存'}</button></div></form>`,esc(char.source));}

function readBPForm(form){const d=new FormData(form),b=Y.bpConfig((pendingImport||c()).state);b.enabled=d.get('bp-enabled')==='yes';for(const k of ['hit','dodge','initiative','melee','weapon','power','defense','pp']){const v=d.get('bp-'+k+'Included');b[k+'Included']=v==='unknown'?null:v==='yes';}b.statsIncluded=['hit','dodge','initiative'].every(k=>b[k+'Included']===true);b.damageIncluded=['melee','weapon','power'].every(k=>b[k+'Included']===true);return b;}
function bpSummary(char){const b=Y.bpBonuses(char),sign=n=>(n>=0?'+':'')+n;const attack=b.meleeDice===b.weaponDice&&b.meleeDice===b.powerDice?`攻撃 ${sign(b.meleeDice)}D6`:`格闘 ${sign(b.meleeDice)}D6／武器 ${sign(b.weaponDice)}D6／能力 ${sign(b.powerDice)}D6`;return `入力値への差分：命中 ${sign(b.hit)}／回避 ${sign(b.dodge)}／行動値 ${sign(b.initiative)}／${attack}／防御 ${sign(b.defense)}／最大PP ${sign(b.ppMax)}。${b.stunImmune?'耐久18以上：気絶無効。':''}`;}
function bpFields(char){const b=Y.bpConfig(char.state),det=char.bpDetection;
 const fields=[['hit','命中のBP補正'],['dodge','回避のBP補正'],['initiative','行動値のBP補正'],['melee','格闘のBP＋1D6'],['weapon','武器のBP＋1D6'],['power','能力のBP＋1D6'],['defense','筋力18以上の防御＋1'],['pp','耐久18以上のPP＋3']];
 const included=k=>['defense','pp'].includes(k)?b[k+'Included']:Y.bpIncluded(b,k),unknown=fields.filter(([k])=>included(k)===null).map(([,label])=>label);
 return `<section class="bp-settings"><div class="row between"><h3>Better Parameter</h3>${select('bp-enabled','このキャラで採用',b.enabled?'yes':'no',[['yes','ON'],['no','OFF']])}</div><p class="usage-note">${det?'シートから自動判定しました。BP設定・基礎値・特化補正・攻撃の取得点を照合しています。':'保存済みの設定を使用します。Excelを読み込むと補正を自動判定します。'}通常はそのまま保存できます。</p>${unknown.length?`<p class="warning">判定できない項目：${esc(unknown.join('、'))}。入力値を保持し、これらの項目にはBP差分を加減算しません。必要な場合のみ詳細設定で変更できます。</p>`:''}<details><summary>自動判定の内訳・詳細設定（通常は変更不要）</summary><p class="usage-note">${det?'シートのBP設定：'+esc(det.flag)+'。':'既存の設定・手動入力値です。'}採用ON／OFFを切り替えても、入力済みの数値は保持して差分だけ反映します。</p><div class="form-grid two">${fields.map(([k,label])=>select('bp-'+k+'Included',label,included(k)===null?'unknown':included(k)?'yes':'no',[['yes','入力値に反映済み'],['no','入力値に含まない'],['unknown','判定保留（入力値を保持）']])).join('')}</div>${det?`<ul class="usage-note">${det.items.map(i=>`<li>${esc(i.label)}：${esc(i.reason)}</li>`).join('')}</ul>`:''}<p class="usage-note">防御＋1・PP＋3はシートの特化補正と重複させません。PP補正の追加・解除時は残PPと最大PPを同量調整します。由来の分からない手入力は自動加算せず、設定を保存して次回も使います。</p></details><p class="notice" id="bp-preview">${bpSummary(char)}</p></section>`;}
function updateBPPreview(){const form=$('#character-form'),out=$('#bp-preview');if(!form||!out)return;const char=Y.clone(pendingImport||c()),d=new FormData(form);char.state.bp=readBPForm(form);char.stats.params=char.stats.params.map((_,i)=>Number(d.get('param'+i)));out.textContent=bpSummary(char);}
function damageDialog(){modal('被ダメージを登録',`<form id="damage-form"><p class="subtle">装甲と増強型の軽減を適用する前の、確定したダメージ判定値を入力します。</p><div class="form-grid two">${input('damageRaw','ダメージ判定値',0,'number','min="0" required')}${select('damageKind','ダメージ種別','physical',[['physical','物理（防御を適用）'],['mental','精神（抵抗を適用）'],['ignore','装甲無視']])}${input('damageNote','メモ','','text')}</div><div class="notice" id="damage-preview"></div><p class="usage-note">増強型はダメージ判定を減算（下限1）、その後に装甲を適用します。最終ダメージは0以上。死力・技のHP消費やHP直接調整には適用しません。</p><div class="form-actions"><button type="button" data-do="close">キャンセル</button><button class="primary">被ダメージを履歴に登録</button></div></form>`);updateDamagePreview();}
function updateDamagePreview(){const f=$('#damage-form');if(!f)return;try{const d=new FormData(f),r=Y.damageTaken(c(),Number(d.get('damageRaw')),d.get('damageKind'));$('#damage-preview').textContent=`判定 ${r.raw} ／ 増強軽減 ${r.reduction} ／ 装甲 ${r.armor} → 被ダメージ ${r.damage}　HP ${c().state.hp} → ${r.afterHP}`;}catch(e){$('#damage-preview').textContent=e.message;}}

function abilityUseInputs(){return c().actions.filter(a=>a.owned&&['SPE','カルマ'].includes(a.group)).map(a=>a.useLimit?input(esc('uses-'+a.id),esc(a.group+' '+a.name+' 残り回数の増減（現在 '+Y.ownedRemaining(c(),a)+' / '+a.useLimit+'）'),0):('<p>'+esc(a.group+' '+a.name)+'：回数調整の対象外（常時・無制限）</p>')).join('');}
const erosion=['制御異常','過負荷','聴覚異常','視覚異常','身体異常','自制','能力異常','言語異常','記憶異常','精神異常','忘我'];
const symptomTables={
 '50%：暴走ロール':['発作','高揚','自制'],
 '70%：暴走ロール':['自爆','暴発','連鎖','発症','自制'],
 '90%：暴走ロール':erosion,
 SO1:['消費負荷','反動','制御成功'],SO2:['自爆','消費負荷','反動','制御成功'],
 SO3:['自爆','消費負荷','過反動','制御成功'],SO4:['崩壊','超負荷','過反動','制御成功'],
 SO5:['崩壊','超負荷','制御成功']
};
function symptomOptions(key){
 return symptomTables[key]||symptomTables[/^(SO[1-5])処理：/.exec(key)?.[1]];
}
function symptomSelect(name,choices){
 return '<label>症状<select required name="'+name+'"><option value="">選択してください</option>'+choices.map(x=>'<option>'+x+'</option>').join('')+'</select></label>';
}
function symptomFields(name){
 const number=(key,label,min,max)=>input(key,label,'','number','required min="'+min+'"'+(max?' max="'+max+'"':''));
 if(['発作','自爆','過負荷','崩壊'].includes(name))return number('damage','自身の被ダメージ',0);
 if(name==='高揚'||name==='連鎖')return number('rise','暴走率上昇（'+(name==='高揚'?'1D':'2D')+'）',name==='高揚'?1:2,name==='高揚'?6:12);
 if(name==='消費負荷'||name==='超負荷')return number('extraPP','追加の実消費PP',0)+number('rise','追加の暴走率上昇',0);
 if(name==='反動'||name==='過反動')return number('penalty','命中・回避の減少値（'+(name==='反動'?'1D':'2D')+'）',name==='反動'?1:2,name==='反動'?6:12);
 if(name==='暴発')return input('target','対象・結果','','text','required')+number('damage','自身の被ダメージ（他者なら0）',0);
 if(name==='発症')return symptomSelect('erosion',erosion)+'<div data-erosion-fields></div>';
 if(name==='回復活性')return number('healHP','HP回復（1D）',1,6)+number('healPP','PP回復（1D）',1,6);
 return '';
}
function symptomDialog(index,key){
 const choices=symptomOptions(key);
 if(!choices&&!key.endsWith('：回復活性'))return false;
 modal(esc(key),'<form id="symptom-form" data-index="'+index+'" data-key="'+esc(key)+'">'+(choices?symptomSelect('symptom',choices):'')+'<div data-symptom-fields>'+(!choices?symptomFields('回復活性'):'')+'</div><div class="form-actions"><button type="button" data-do="close">キャンセル</button><button class="primary">結果を記録</button></div></form>');
 return true;
}
function adjustDialog(resolve=false){const s=c().state,index=Number.isInteger(resolve)?resolve:null,entry=index===null?null:s.pending?.[index];if(index!==null&&entry===undefined){toast('一覧から選び直してください');return;}if(entry&&symptomDialog(index,entry))return;modal(index!==null?'追加処理を記録':'状態を調整',`<form id="adjust-form" data-resolve="${index!==null}" data-pending-index="${index??''}" data-pending-key="${esc(entry??'')}"><p class="subtle" style="margin-bottom:18px">回復・シーンチェック・臨界因子など、実際の増減を入力します。攻撃を受ける場合は「被ダメージ」で装甲・増強軽減を計算できます。</p><div class="form-grid">${input('hp','HP増減',0)}${input('pp','PP増減（回復・直接増減）',0)}${input('rage','暴走率増減',0)}${input('factor','因子増減（Rd）',0)}${input('costPP','消費PP（総消費と暴走に加算）',0,'number','min="0"')}${input('hpMax','セッション最大HP',s.hpMax,'number','min="1"')}${input('ppMax','セッション最大PP',s.ppMax,'number','min="0"')}${abilityUseInputs()}${input('reason','メモ',index!==null?Y.pendingLabel(entry):'状態調整','text','required')}</div><p class="usage-note">SPE・カルマは正数で残り回数を回復、負数で消費します。上限は所持品に設定した使用回数です。この画面のHP直接増減には装甲・増強軽減を適用しません。「PP増減」は総消費PP・暴走率を変更しません。PPを消費する場合は「消費PP」を使います。HP/PPの回復はセッション最大値で止まります。</p>${index!==null?'<p class="warning">暴走・臨界ロール、回復型の活性回復、臨界域の因子獲得は実際の結果を入力してください。</p>':''}<div class="form-actions"><button type="button" data-do="close">キャンセル</button><button class="primary">調整を履歴に登録</button></div></form>`);}
function buffEffectRow(e={stat:'hit',flat:0,dice:0,mult:1}){return `<div class="buff-effect form-grid two">${select('stat','補正項目',e.stat,[['','補正項目を選択'],...['hit','dodge','ss','defense','resist','initiative','precision','spec'].map(k=>[k,Y.labels[k]]),['damage','全攻撃のダメージ'],['melee','格闘ダメージ'],['weapon','武器ダメージ'],['power','能力ダメージ'],['allChecks','命中・回避・SS・技能'],['skill','技能・解除'],['release','解除判定'],...Y.skillNames.map(k=>['skill:'+k,k])])}${input('flat','固定値の増減',e.flat)}${input('dice','ダイスの増減',e.dice)}${select('mult','固定値の倍率',e.mult,[[1,'×1'],[.5,'×0.5'],[2,'×2'],[0,'×0']])}<button type="button" data-do="remove-buff-effect">この項目を外す</button></div>`;}
function buffDialog(b){b=b||{id:Y.id(),name:'',target:'self',stat:'hit',flat:0,dice:0,mult:1,active:true,endRound:''};modal('盤面の補正を登録',`<form id="buff-form" data-id="${esc(b.id)}"><div class="form-grid two">${input('name','バフ・デバフ名',b.name,'text','required')}${select('target','対象',b.target,[['self','自分'],['enemy','相手'],['both','両者']])}${input('endRound','有効な最終ラウンド（空欄＝継続）',b.endRound,'number','min="1"')}<label class="checkbox"><input type="checkbox" name="active" ${b.active!==false?'checked':''}>有効</label></div><div id="buff-effects">${(b.effects||[b]).map(buffEffectRow).join('')}</div><button type="button" data-do="add-buff-effect">＋ 補正項目を追加</button><div class="form-actions">${c().state.buffs.some(x=>x.id===b.id)?`<button type="button" class="danger" data-do="delete-buff" data-id="${b.id}">バフを削除</button>`:''}<button type="button" data-do="close">キャンセル</button><button class="primary">補正を保存</button></div></form>`);}
function buffEffectsLabel(b){return (b.effects||[b]).map(e=>`${Y.labels[e.stat]||({damage:'ダメージ',skill:'技能・解除',allChecks:'すべての判定'})[e.stat]||esc(e.stat)} ${e.flat>=0?'+':''}${e.flat}${e.dice?' / '+(e.dice>0?'+':'')+e.dice+'D6':''}${e.mult!==1?' / ×'+e.mult:''}`).join('<br>');}
let editingOwned=null;
async function copyText(text,success='コピーしました'){
 const doc=uiDocument;
 if(!text)return;
 const manual=()=>{withSurface(doc,()=>modal('コピーする内容',`<textarea id="copy-value" readonly>${esc(text)}</textarea><p class="usage-note">コピーが許可されていない場合は、選択された内容をCtrl+Cでコピーしてください。</p>`));doc.querySelector('#copy-value').select();};
 if(window.chrome?.webview){if(text.length>32768){manual();return;}window.chrome.webview.postMessage('copy:'+encodeURIComponent(text));return;}
 try{await doc.defaultView.navigator.clipboard.writeText(text);withSurface(doc,()=>toast(success));}
 catch(e){manual();}
}
function optionsDialog(){
 const link=compactDesktop?new URL(WINDOWS_DOWNLOAD,'https://wolfuls.github.io/Other/Ulfhamr/').href:WINDOWS_DOWNLOAD;
 const groups=[['画面',Theme.fields.slice(0,6)],['ボタン・強調',Theme.fields.slice(6,10)],['サイドバー・しおり',Theme.fields.slice(10,12)],['警告・エラー',Theme.fields.slice(12)]];
 const fields=groups.map(([group,items])=>`<div class="theme-color-group"><h4>${group}</h4><div class="theme-color-grid">${items.map(([key,label])=>`<div class="theme-color-entry"><span>${label}</span><div class="theme-color-controls"><input type="color" data-theme-color="${key}" value="${themeState.colors[key]}" aria-label="${label}の色"><input type="text" data-theme-color="${key}" value="${themeState.colors[key]}" maxlength="7" spellcheck="false" aria-label="${label}の色コード"></div></div>`).join('')}</div></div>`).join('');
 modal('オプション',`<p class="usage-note"><a href="${firefoxMode||compactDesktop?'https://wolfuls.github.io/Other/Ulfhamr/':'index.html'}" target="_blank" rel="noopener">配布ページ・取扱説明書 ↗</a></p><div class="option-section"><h3>カラーテーマ</h3><p class="subtle">テンプレートを選ぶと全ての色がその初期値になります。色は個別にも調整でき、自動で保存されます。</p><div class="theme-options" role="group" aria-label="テーマのテンプレート">${[['light','ライトモード'],['dark','ダークモード']].map(([value,label])=>`<button type="button" class="theme-choice ${colorTheme===value?'active':''}" data-do="set-theme" data-theme="${value}" aria-pressed="${colorTheme===value}"><span class="theme-swatch ${value}" aria-hidden="true"><i></i><i></i><i></i></span><span><b>${label}</b><small>テンプレートを適用</small></span></button>`).join('')}</div><p class="theme-summary" data-theme-summary>${colorTheme==='dark'?'ダーク':'ライト'}をベース${Theme.customized(themeState)?'（色を調整済み）':''}</p><p class="usage-note">色見本をクリックするか、#RRGGBB 形式の色コードを入力してください。</p>${fields}</div><div class="option-section"><h3>データ管理</h3><div class="row wrap"><button data-do="export">バックアップ</button><button data-do="restore-file">復元</button><button data-do="manual">手動作成</button></div></div>${firefoxMode?'':`<div class="option-section web-download"><h3>Windows版</h3><p class="subtle">64bit版のZIPをダウンロードして展開し、Ulfhamr.exe を起動します。</p><a class="download-option" href="${link}" ${compactDesktop?'target="_blank" rel="noopener"':`download="${WINDOWS_FILE}"`}>Windows版をダウンロード ↓</a><p class="usage-note">HTML版とWindows版の保存データは別々です。バックアップから移せます。</p></div>`}<div class="form-actions"><button class="primary" data-do="close">閉じる</button></div>`);
}
function inventorySection(){return `<p class="usage-note">キャラシートの初回読み込みで所持品も取り込みます。追加・変更時のみ再読込してください。</p><div class="panel-head"><h3>所持する特殊武装・SPE・カルマ・消費アイテム</h3><div class="row wrap"><button data-do="inventory-import">所持品を再読込</button><button data-do="inventory-add">＋ 登録</button></div></div>${c().actions.filter(a=>a.owned).map(a=>`<div class="buff-row"><span class="tag">${esc(a.group)}</span><div><b>${esc(a.name)}</b><small>${esc(Y.ownedCountLabel(c(),a))}${a.consumable?'（各1回）':''}${a.needsReview?'・要確認':''}</small></div><button class="small" data-do="inventory-edit" data-id="${a.id}">編集</button></div>`).join('')||'<p class="subtle">キャラシートから読み込むか、所持しているものを登録してください。</p>'}`;}
function inventoryDialog(a){
 editingOwned=a?Y.clone(a):{id:Y.id(),name:'',group:'消費アイテム',owned:true,pp:0,hp:0,factor:0,rage:0,spec:0,quantity:1,phases:['IN','AC','RE','EN','EX'],manualEffect:true};const x=editingOwned;
 modal('所持品を登録・編集',`<form id="inventory-form"><label>ルールから選ぶ<select name="owned-preset"><option value="">名称・効果を手動で設定</option>${Y.ownedGroups.map(g=>`<optgroup label="${g}">${Y.ownedCatalog.filter(v=>v.group===g).map(v=>`<option value="${v.catalogKey}" ${v.catalogKey===x.catalogKey?'selected':''}>${esc(v.name)}</option>`).join('')}</optgroup>`).join('')}</select></label><div class="form-grid" style="margin-top:16px">${input('name','名前',x.name,'text','required')}${select('group','分類',x.group,Y.ownedGroups)}${input('quantity','所持数（武装のHPボーナス計算にも使用）',x.quantity??1,'number','min="0" max="99" required')}${input('remaining','残数 / 残り使用回数',c().actions.some(a=>a.id===x.id)?Y.ownedRemaining(c(),x)??0:x.consumable?x.quantity??1:x.useLimit||0,'number','min="0" max="999" required')}${input('useLimit','使用回数の上限（0＝無制限）',x.useLimit||0,'number','min="0" max="999"')}${select('usePeriod','使用回数の区切り',x.usePeriod||'session',[['session','セッション'],['battle','バトル'],['round','ラウンド']])}${input('pressure','特殊武装の圧迫SP',x.pressure??'','number','min="0" max="100"')}${input('pp','固定のPP消費',x.pp||0,'number','min="0"')}${input('hp','固定のHP消費',x.hp||0,'number','min="0"')}${input('factor','因子消費（Rd）',x.factor||0,'number','min="0"')}${input('rage','追加の暴走率上昇',x.rage||0,'number','min="0"')}<label class="checkbox"><input name="passive" type="checkbox" ${x.passive?'checked':''}>常時効果（宣言不要）</label><label class="checkbox"><input name="main" type="checkbox" ${x.main?'checked':''}>メイン行動を使用</label><div class="span-all"><label>宣言できるフェイズ</label><div class="row wrap">${Object.keys(Y.phases).map(k=>`<label class="checkbox"><input type="checkbox" name="phase-${k}" ${x.phases.includes(k)?'checked':''}>${k}</label>`).join('')}</div></div><label class="span-all">効果・条件<textarea name="note" rows="6">${esc(x.note||'')}</textarea></label></div><p class="usage-note">消費アイテムの価格は購入時の因子です。使用時には残数だけを減らします。回数無制限では「残り使用回数」は使いません。所持品の常時効果や圧迫SPは、読み込んだ基礎ステータスに再加算しません。${x.variableCosts?.length||x.dynamicPP?'この効果の変動コストは宣言時に決定します。':''}</p>${/^https:\/\/wolfuls\.github\.io\/YggRW\//.test(x.ruleUrl||'')?`<a href="${esc(x.ruleUrl)}" target="_blank" rel="noopener">ルールの詳細 ↗</a>`:''}<div class="form-actions">${c().actions.some(a=>a.id===x.id)?`<button type="button" class="danger" data-do="delete-action" data-id="${x.id}">削除</button>`:''}<button type="button" data-do="close">キャンセル</button><button class="primary">この内容で登録</button></div></form>`);
}
function conditionDialog(){
 const char=c(),old=char.state.condition,bonus=old?.weaponBonus??Y.weaponBonus(char),hp=old?.hpRoll??(old?old.hp-bonus:''),pp=old?.ppRoll??old?.pp??'',maximum=char.actions.find(a=>a.conditionItem&&Y.ownedRemaining(char,a)>0),unknown=char.actions.filter(a=>a.owned&&a.group==='特殊武装'&&a.pressure==null);
 modal('コンディションロール',`<form id="condition-form"><p class="subtle">ユドナリウム等で振った2D6の合計を入力してください。HP・PPにそれぞれ出目を加算し、PPの上昇分だけ暴走率も上げます。HPには特殊武装の圧迫SP×3を加えます。</p>${old?`<div class="notice">登録済み：HP +${old.hp} / PP +${old.pp}。${old.source==='sheet'?'進行表のコンディションを読み込みました。':old.source==='maxima'?'進行表の最大値と基礎値の差を反映済みとして扱っています。':''}今回の値との差分だけ反映します。</div>`:''}<div class="form-grid condition-fields">${input('hpRoll','HP：2D6の合計',hp,'number','min="2" max="12" required')}${input('ppRoll','PP：2D6の合計',pp,'number','min="2" max="12" required')}${input('bonus','特殊武装によるHPボーナス',bonus,'number','min="0" max="300" required')}${old?select('reroll','今回の処理','yes',[['yes','振り直し（1 Rd消費）'],['no','入力内容の訂正（振り直しではない）']]):'<input name="reroll" type="hidden" value="no">'}${!old&&maximum?`<label class="checkbox span-all"><input name="maximumId" type="checkbox" value="${maximum.id}">マキシマムを1個使用（HP・PPの出目を10に固定）</label>`:''}</div>${unknown.length?`<p class="warning">圧迫SP未確認：${unknown.map(a=>esc(a.name)).join('、')}。HPボーナスを確認してください。</p>`:''}<div id="condition-preview" class="notice"></div><p class="usage-note">HP・PPの現在値と最大値を同じ差分で更新し、既に受けたダメージやPP消費を保持します。コンディションのPP上昇は総消費PPに加算しません。登録した内容は履歴から巻き戻せます。</p><div class="form-actions"><button type="button" data-do="close">キャンセル</button><button class="primary">コンディションを反映</button></div></form>`);updateConditionPreview();
}
function conditionValues(form){const d=new FormData(form),maximumId=d.get('maximumId');return {hpRoll:maximumId?10:Number(d.get('hpRoll')),ppRoll:maximumId?10:Number(d.get('ppRoll')),bonus:Number(d.get('bonus')),reroll:d.get('reroll')==='yes',maximumId};}
function updateConditionPreview(){const f=$('#condition-form');if(!f)return;const maximum=f.elements.maximumId?.checked;for(const k of ['hpRoll','ppRoll']){f.elements[k].required=!maximum;if(maximum)f.elements[k].value=10;}try{const copy=Y.clone(c());Y.applyCondition(copy,conditionValues(f));const s=copy.state;$('#condition-preview').textContent=`反映後：HP ${s.hp} / ${s.hpMax}、PP ${s.pp} / ${s.ppMax}、暴走率 ${s.rage}%、因子 ${s.factor} Rd`;}catch(e){$('#condition-preview').textContent=e.message;}}

function customDialog(a){a=a||{id:Y.id(),name:'',pp:0,hp:0,factor:0,rage:0,spec:0,note:'',group:'カスタム',phases:['AC','RE','EX'],main:false,attack:''};modal('行動を登録',`<form id="custom-form" data-id="${esc(a.id)}"><div class="form-grid">${input('name','行動・技の名前',a.name,'text','required')}${select('ppMode','PPの決め方',a.ppMode||'fixed',[['fixed','固定のPP消費'],['creation','創造系：固定追加＋1〜10PP']])}${input('pp','PP消費（創造系では固定追加分のみ）',a.pp,'number','min="0" required')}${input('hp','HP消費',a.hp||0,'number','min="0"')}${input('factor','因子消費（Rd）',a.factor||0,'number','min="0"')}${input('rage','追加の暴走率上昇',a.rage||0,'number','min="0"')}${input('spec','必要スペック（負数＝常時圧迫）',a.spec||0,'number')}${select('attack','攻撃種別',a.attack||'',[['','攻撃以外・個別処理'],['melee','格闘'],['weapon','武器'],['power','能力']])}${select('group','分類',a.group,[['応用技','応用技'],['カスタム','特殊武装・SPE等']])}<label class="checkbox"><input name="main" type="checkbox" ${a.main?'checked':''}>メイン行動を使用</label><div class="span-all"><label>宣言可能なフェイズ</label><div class="row wrap" style="margin-top:8px">${Object.entries(Y.phases).map(([k,v])=>`<label class="checkbox"><input type="checkbox" name="phase-${k}" ${a.phases.includes(k)?'checked':''}>${k}</label>`).join('')}</div></div><label class="span-all">効果・条件・メモ<textarea name="note">${esc(a.note)}</textarea></label></div><p class="usage-note">創造系は、ここでは他の効果の固定追加PPだけを設定します（純粋な創造なら0）。創造PPは行動に追加するたび1〜10から選びます。PP消費分の暴走率は自動加算します。特殊武装など、PPを伴わない上昇は「追加の暴走率上昇」に入力します。</p><div class="form-actions">${c().actions.some(x=>x.id===a.id)?`<button type="button" class="danger" data-do="delete-action" data-id="${a.id}">削除</button>`:''}<button type="button" data-do="close">キャンセル</button><button class="primary">行動を保存</button></div></form>`);}
let savingHistory=false;
async function persistHistory(operation,done){
 if(savingHistory)return;savingHistory=true;const char=c(),original=Y.clone(char),index=db.characters.indexOf(char),app=document.getElementById('app');app.inert=true;
 try{const event=operation(char);if(!save()||!await UlfStorage.flush()){db.characters[index]=original;return;}done();render();notifyLycoris(event);}
 finally{app.inert=false;savingHistory=false;}
}
const handlers={
 close:()=>$('#modal').close(),
 tab:el=>{if(compactDesktop&&window.chrome?.webview&&(popupTitles[el.dataset.tab]||uiDocument!==document)){window.chrome.webview.postMessage('open:'+el.dataset.tab);return;}tab=el.dataset.tab;render();uiDocument.defaultView.scrollTo(0,0);},
 switch:el=>{db.activeId=el.dataset.id;draft=[];desperate=0;note='';save();render();},
 import:importDialog,
 'choose-xlsx':()=>{importMode=$('[name="import-mode"]').value;$('#xlsx-file').click();},
 manual:()=>characterDialog(Y.emptyCharacter(),true),
 demo:()=>{const char=Y.emptyCharacter('サンプル・エージェント');char.source='操作確認用デモ（架空の値）';char.state.rage=58;char.state.spent=14;char.state.factor=4;char.initial=Y.clone(char.state);char.actions.push({id:Y.id(),name:'フォース・インパクト',pp:3,hp:0,factor:0,rage:0,phases:['AC'],group:'応用技',spec:2,note:'デモ用の攻撃発動。能力攻撃力を使用。',attack:'power',main:true});db.characters.push(char);db.activeId=char.id;save();render();},
 'clear-search':()=>{search='';render();$('#action-search').focus();},
 mode:el=>{if(draft.length){toast('登録前の宣言があります。登録するか、候補を外してから切り替えてください。');return;}Y.setMode(c(),el.dataset.mode);save();render();},
 phase:el=>modal('フェイズを切り替えますか？',`<p><b>${esc(el.dataset.phase)} / ${esc(Y.phases[el.dataset.phase])}</b>へ切り替え、今回の宣言${draft.length?'（'+draft.length+'件）':''}とメモを空にします。</p><p class="subtle">まだ登録していない消費は状態に反映されません。</p><div class="form-actions"><button data-do="close">キャンセル</button><button class="primary" data-do="confirm-phase" data-phase="${esc(el.dataset.phase)}">OK・切り替える</button></div>`),
 'confirm-phase':el=>{Y.changePhase(c(),el.dataset.phase);draft=[];desperate=0;note='';save();$('#modal').close();render();},
 'next-round':()=>{if(draft.length){toast('登録前の宣言があります。登録するか、候補を外してください。');return;}Y.nextRound(c());save();render();toast('次のラウンドを開始しました');},
 'add-action':el=>{const a=Y.allActions(c()).find(a=>a.id===el.dataset.id);if(!a)return;if(draft.some(r=>Y.sameAction(r.action,a))){toast('この行動は今回の宣言に追加済みです。');return;}const reason=Y.available(c(),a,draft);if(reason){toast(reason);return;}const row=commandRow(a),invalid=Y.declarationInputError(row)||Y.ppBudget(c(),[...draft,row],desperate).error;if(invalid){toast(invalid);return;}draft.push(row);if(el.closest('.pending-body'))$('#modal').close();render();},
 'add-funded':el=>{const a=Y.allActions(c()).find(a=>a.id===el.dataset.id);if(!a||Y.available(c(),a,draft)||Y.declarationInputError(commandRow(a))||draft.some(r=>Y.sameAction(r.action,a)))return;const b=Y.ppBudget(c(),[...draft,commandRow(a)],desperate);if(!b.error||!b.canFund)return;desperate=b.required;handlers['add-action'](el);},
 'cancel-charge':()=>{Y.cancelCharge(c());draft=draft.filter(r=>!r.action.chargeStep);save();render();},
 'reset-exploration':()=>{c().state.explorationCheck={...c().state.explorationCheck,ownFixed:null,ownDice:null};save();render();},
 'buff-from-technique':el=>{const r=draft[Number(el.dataset.index)];if(!r)return;const b=Y.techniqueBonuses(c(),r,draft);if(!b.items.length)return;b.effects=b.items.map(x=>({stat:x.stat||'',flat:x.flat,dice:x.dice,mult:1}));buffDialog({id:'tech-buff-'+r.action.id,name:r.action.name,target:b.items.every(x=>x.flat<=0&&x.dice<=0)?'enemy':'self',...b.effects[0],effects:b.effects,active:true,endRound:''});},
 'remove-draft':el=>{draft.splice(Number(el.dataset.index),1);render();},
 roll:el=>{const r=draft[Number(el.dataset.index)];let total=0;const n=r.action.rollDice*r.level;const rolls=[];for(let i=0;i<n;i++){const v=new Uint32Array(1);let x;do{crypto.getRandomValues(v);x=v[0];}while(x>=4294967292);const d=x%6+1;rolls.push(d);total+=d;}r.result=total;render();toast(rolls.join(' + ')+' = '+total);},
 commit:()=>persistHistory(char=>Y.commit(char,draft,desperate,note),()=>{draft=[];desperate=0;note='';toast('宣言を登録しました');}),
 condition:()=>conditionDialog(),
 'copy-status':()=>copyResource(),
 'export-token':()=>exportToken(),
  'copy-draft':()=>copyText(Y.declarationCopy(c(),Y.resolveDeclarationRows(c(),draftEntries().map(({r})=>r)),desperate,note),'今回の宣言をコピーしました'),
  'copy-draft-action':el=>copyText(Y.declarationActionCopy(Y.resolveDeclarationRows(c(),[draft[Number(el.dataset.index)]])[0]),'行動をコピーしました'),
  options:optionsDialog,
  'set-theme':el=>setTheme(el.dataset.theme),
 'inventory-add':()=>inventoryDialog(),
 'inventory-edit':el=>inventoryDialog(c().actions.find(a=>a.id===el.dataset.id)),
 'inventory-import':()=>{importMode='inventory';$('#xlsx-file').click();},
 damage:()=>damageDialog(),
 adjust:()=>adjustDialog(),
 pending:()=>modal('保留中の処理',pendingView(c())),
 'resolve-pending':el=>adjustDialog(Number(el.dataset.index)),
 'add-buff':()=>buffDialog(),
 'add-buff-effect':()=>$('#buff-effects').insertAdjacentHTML('beforeend',buffEffectRow()),
 'remove-buff-effect':el=>{if($('#buff-effects').children.length>1)el.closest('.buff-effect').remove();else toast('補正項目は1つ以上必要です');},
 'edit-buff':el=>buffDialog(c().state.buffs.find(b=>b.id===el.dataset.id)),
 'delete-buff':el=>{const s=Y.clone(c().state),b=s.buffs.find(b=>b.id===el.dataset.id);s.buffs=s.buffs.filter(b=>b.id!==el.dataset.id);Y.record(c(),'補正を削除：'+b.name,s,{},'buff');save();$('#modal').close();render();},
 'custom-action':()=>customDialog(),
 'edit-action':el=>customDialog(c().actions.find(a=>a.id===el.dataset.id)),
 'delete-action':el=>{c().actions=c().actions.filter(a=>a.id!==el.dataset.id);save();$('#modal').close();render();},
 'edit-character':()=>characterDialog(c()),
 rollback:el=>{const id=el.dataset.id,e=c().history.find(e=>e.id===id),s=id==='initial'?c().initial:e?.after;if(!s)return;modal('この状態へ巻き戻す',`<p>${esc(e?.title||'読み込み時の状態')}</p><div class="notice">${Y.isBattle(s)?'R'+s.round+' / '+Y.phases[s.phase]:'探索中'} / HP ${s.hp} / PP ${s.pp} / 暴走 ${s.rage}% / 因子 ${s.factor} Rd / 総消費 ${s.spent}PP</div><p class="subtle">盤面の補正、相手の状態、BP設定も復元します。既存の履歴は残ります。</p><div class="form-actions"><button data-do="close">キャンセル</button><button class="primary" data-do="confirm-rollback" data-id="${esc(id)}">この状態へ戻る</button></div>`);},
 'confirm-rollback':el=>persistHistory(char=>Y.rollback(char,el.dataset.id),()=>{draft=[];desperate=0;$('#modal').close();toast('選んだ状態に戻しました');}),
 'delete-character':()=>modal('キャラクターを削除',`<p>「${esc(c().name)}」とこのキャラの全履歴を削除します。</p><div class="form-actions"><button data-do="export">先にバックアップ</button><button data-do="close">キャンセル</button><button class="danger" data-do="confirm-delete">削除する</button></div>`),
 'confirm-delete':()=>{db.characters=db.characters.filter(x=>x.id!==c().id);db.activeId=db.characters[0]?.id;draft=[];desperate=0;save();$('#modal').close();render();},
 export:()=>download(JSON.stringify({...db,exportedAt:new Date().toISOString()},null,2),'Ulfhamr-Backup-'+new Date().toISOString().slice(0,10)+'.json'),
 'export-raw':()=>download(UlfStorage.getItem(KEY)||'','Ulfhamr-Recovery.json'),
 'restore-file':()=>document.querySelector('#json-file').click(),
 'export-history':()=>{const rows=[['日時','進行モード','ラウンド','フェイズ','行動','HP','PP','暴走率','因子（Rd）','総消費PP','今回消費PP','今回総消費','メモ'],...c().history.map(e=>[e.time,e.phase==='EX'?'探索中':'バトル中',e.phase==='EX'?'':e.round,e.phase,e.title,e.after.hp,e.after.pp,e.after.rage,e.after.factor,e.after.spent,e.detail?.pp||0,e.detail?.spent||0,e.detail?.note||''])];download('\uFEFF'+rows.map(r=>r.map(x=>'"'+String(x).replace(/^[=+@-]/,"'$&").replace(/"/g,'""')+'"').join(',')).join('\r\n'),'Ulfhamr-History.csv','text/csv;charset=utf-8');},
 'opponent-from-character':()=>modal('保存キャラを比較対象にする',`<p class="subtle">選んだキャラの現在の活性・補正を含めた値をコピーします。</p><div class="form-actions">${db.characters.map(x=>`<button data-do="set-opponent" data-id="${esc(x.id)}">${esc(x.name)}</button>`).join('')}</div>`),
 'set-opponent':el=>{const other=db.characters.find(x=>x.id===el.dataset.id),cmp=comparison(),checks=Object.fromEntries(['hit','dodge','ss'].map(k=>[k,Y.effective(other,k)])),v=checks[cmp.enemyKey];const s=Y.clone(c().state);s.opponent={name:other.name,hp:other.state.hp,fixed:v.fixed,dice:v.dice,checkKey:cmp.enemyKey,checks,defense:Y.effective(other,'defense').fixed,resist:Y.effective(other,'resist').fixed,rage:other.state.rage,activation:other.activation};Y.record(c(),'比較対象：'+other.name,s,{},'opponent');save();$('#modal').close();render();},
};

function withSurface(doc,fn){
 const previousDoc=uiDocument,previousTab=tab,context=surfaces.get(doc);
 uiDocument=doc;tab=context.tab;
 try{return fn();}finally{context.tab=tab;uiDocument=previousDoc;tab=previousDoc===doc?context.tab:previousTab;}
}
const surfaceListeners=[];
function listen(doc,type,handler,options){
 if(doc===document)surfaceListeners.push([type,handler,options]);
 doc.addEventListener(type,e=>withSurface(doc,()=>handler(e)),options);
}
function syncSurfaceLocks(){
 let owner=null;for(const doc of surfaces.keys())if(doc.querySelector('#modal')?.open){owner=doc;break;}
 for(const doc of surfaces.keys()){const app=doc.querySelector('#app');if(app)app.inert=!!owner&&owner!==doc;}
}
function render(exceptDocument=null){
 surfaces.get(uiDocument).tab=tab;
 for(const [doc,context] of surfaces){
  if(doc===exceptDocument)continue;
  if(doc!==document&&doc.defaultView.closed){surfaces.delete(doc);continue;}
  withSurface(doc,()=>{
   if(doc===document){renderOne();return;}
   doc.body.className='companion-mode independent-window';
   Theme.apply(doc,themeState);
   $('#app').innerHTML='<main class="main"><div class="window-topbar"><p class="window-character">'+esc(c()?.name||popupTitles[tab])+'</p><button class="small" data-do="options">⚙ オプション</button></div>'+(c()?(tab==='actions'?actionsView():tab==='compare'?declarationView():buffView()):'<div class="panel"><h2>'+popupTitles[tab]+'</h2><p>「今回の宣言」からキャラクターを読み込んでください。</p><button data-do="tab" data-tab="draft">今回の宣言を開く</button></div>')+'</main>';
   if(c()&&['draft','compare'].includes(tab))calculate();
  });
 }
 syncSurfaceLocks();
}
window.addEventListener('ygg-open-popup',e=>{
 const key=e.detail;if(!popupTitles[key]||!window.chrome?.webview)return;
 const child=window.open('about:blank','ygg-'+key,'popup,width=760,height=960');
 if(!child){window.chrome.webview.postMessage('popup-failed:'+key);toast('ウィンドウを開けませんでした。もう一度しおりを押してください。');return;}
 // Wait until the native WebView is attached; do not run another application instance.
 const attach=()=>{
  try{
   if(child.closed)return;
   const doc=child.document;
   if(surfaces.has(doc))return;
   doc.open();doc.write('<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+popupTitles[key]+' — 情報拡張装置【ウールヴハム】</title><link rel="stylesheet" href="https://ygg-round.example/styles.css?v=1.16"></head><body><input id="xlsx-file" type="file" accept=".xlsx" hidden><div id="app"></div><div id="toast" role="status"></div><dialog id="modal"><div id="modal-content"></div></dialog></body></html>');doc.close();
   surfaces.set(doc,{tab:key});bindImport(doc);
   for(const [type,handler,options] of surfaceListeners)listen(doc,type,handler,options);
   doc.addEventListener('close',syncSurfaceLocks,true);
   render();
  }catch(error){toast('独立ウィンドウの初期化に失敗しました：'+error.message);}
 };
 attach();
});
window.addEventListener('ygg-hide-popup',e=>{
 for(const [doc,context] of surfaces)if(doc!==document&&context.tab===e.detail)doc.querySelector('#modal')?.close();
 syncSurfaceLocks();
});
document.addEventListener('close',syncSurfaceLocks,true);

window.addEventListener('ygg-options',()=>withSurface(document,()=>{if([...surfaces.keys()].some(doc=>doc.querySelector('#modal')?.open)){toast('編集中の画面を閉じてからオプションを開いてください。');return;}optionsDialog();}));
window.addEventListener('ygg-desktop',e=>{const d=e.detail;if(!d||typeof d.compact!=='boolean'||!['actions','draft','compare','buffs','history','character'].includes(d.tab))return;const previousTab=tab;compactDesktop=d.compact;if(!$('#modal').open)tab=d.tab;else toast('編集中の画面を閉じてからトレイを切り替えてください。');surfaces.get(document).tab=tab;render();if(tab!==previousTab)window.scrollTo(0,0);});
listen(document,'click',async e=>{const el=e.target.closest('[data-do]');if(!el)return;try{await handlers[el.dataset.do]?.(el);}catch(err){toast(err.message||String(err));}});
const composingSearch=new WeakSet(),wheelAmounts=new WeakMap();
listen(document,'wheel',wheelSelect,{passive:false});
function refreshActionSearch(el){
 search=el.value;
 for(const [doc] of surfaces){
  const grid=doc.querySelector('.action-command-grid');if(!grid)continue;
  withSurface(doc,()=>{const template=doc.createElement('template');template.innerHTML=actionCommands();grid.replaceWith(template.content.firstElementChild);const input=doc.querySelector('#action-search');if(input!==el&&!composingSearch.has(input))input.value=search;});
 }
}
listen(document,'compositionstart',e=>{if(e.target.id==='action-search')composingSearch.add(e.target);});
listen(document,'compositionend',e=>{if(e.target.id==='action-search'){composingSearch.delete(e.target);refreshActionSearch(e.target);}});
listen(document,'input',e=>{const el=e.target;if(el.dataset.commandField){updateCommandInput(el);return;}if(el.dataset.themeColor){setThemeColor(el);return;}if(el.form?.id==='condition-form')updateConditionPreview();if(el.form?.id==='damage-form')updateDamagePreview();if(el.form?.id==='character-form')updateBPPreview();if(el.id==='action-note')note=el.value;if(el.id==='action-search'&&!e.isComposing&&!composingSearch.has(el)){refreshActionSearch(el);}});
listen(document,'change',e=>{const el=e.target;try{
 if(el.form?.id==='symptom-form'&&['symptom','erosion'].includes(el.name)){
  el.form.querySelector('[data-'+el.name+'-fields]').innerHTML=symptomFields(el.value);return;
 }

 if(el.dataset.commandField){updateCommandInput(el);return;}
 if(el.dataset.themeColor){if(!Theme.validColor(el.value.trim()))toast('色コードは #RRGGBB の形式で入力してください。');return;}
 if(el.form?.id==='condition-form')updateConditionPreview();if(el.form?.id==='damage-form')updateDamagePreview();if(el.form?.id==='character-form')updateBPPreview();
 if(el.name==='owned-preset'){const preset=Y.ownedCatalog.find(a=>a.catalogKey===el.value);if(preset)inventoryDialog({...Y.clone(preset),id:editingOwned.id,quantity:1});return;}
 if(el.id==='companion-character'){handlers.switch({dataset:{id:el.value}});return;}
 if(el.dataset.actionPick){selectedActions[el.dataset.actionPick]=el.value;const id=el.id;refreshActionSearch($('#action-search'));uiDocument.getElementById(id)?.focus();return;}
 if(el.dataset.draft){const r=draft[Number(el.dataset.index)],key=el.dataset.draft,previous=r[key];r[key]=['target','itemTarget','trapStage','trapTarget','trapLabel','trapTrigger','trapResult'].includes(key)?el.value:el.value===''?null:Number(el.value);const shortage=Y.ppBudget(c(),draft,desperate).error;if(shortage){r[key]=previous;toast(shortage);}render();}
 if(el.id==='desperate'){desperate=Number(el.value);render();}
 if(el.id==='campaign-info'){c().state.info=el.value;save();}
 if(el.dataset.buffToggle){const s=Y.clone(c().state),b=s.buffs.find(b=>b.id===el.dataset.buffToggle);b.active=el.checked;Y.record(c(),'補正'+(b.active?'ON':'OFF')+'：'+b.name,s,{},'buff');save();render();}
 if(el.name.startsWith('explore-')){const key=el.name.slice(8),value=el.value===''?null:Number(el.value);if(!['ownFixed','ownDice','targetFixed','targetDice'].includes(key))return;if(value!==null&&(!Number.isInteger(value)||Math.abs(value)>10000||key.endsWith('Dice')&&(value<0||value>100)))throw Error('固定値は±10000、ダイス数は0〜100の整数です');c().state.explorationCheck={...c().state.explorationCheck,[key]:value};save();render(uiDocument);calculate();}
 if(el.name.startsWith('compare-')){const key=el.name.slice(8);compareOpts[key]=el.type==='checkbox'?el.checked:el.type==='number'?Number(el.value):el.value;if(key==='selection')render();else calculate();}
 if(el.name.startsWith('enemy-')){const s=Y.clone(c().state),key=el.name.slice(6),textKey=['name','activation'].includes(key),value=textKey?el.value:el.value===''?null:Number(el.value);
  if(!textKey&&value!==null&&!Number.isSafeInteger(value))throw Error('相手の数値を確認してください');
  if(key==='dice'&&value!==null&&(value<0||value>20))throw Error('相手のダイス数は0〜20で指定してください');
  if(['fixed','dice'].includes(key))s.opponent=Y.withOpponentCheck(s.opponent,comparison().enemyKey,key,value);else s.opponent[key]=value??0;
  Y.record(c(),'比較対象を更新：'+s.opponent.name,s,{},'opponent');save();render(uiDocument);calculate();}

 }catch(err){toast(err.message);}});
listen(document,'submit',e=>{e.preventDefault();const f=e.target,d=new FormData(f),n=k=>{const v=Number(d.get(k));if(!Number.isFinite(v)||!Number.isInteger(v))throw Error('整数で入力してください：'+k);return v;};try{
 if(f.id==='character-form'){
  const isNew=!!pendingImport,original=isNew?pendingImport:c(),char=Y.clone(original),previousPPBonus=Y.bpBonuses(original).ppMax,resolved=[];
  if(isNew){char.actions.forEach((a,i)=>(a.importMissing||[]).forEach(m=>{const key='import-action-'+i+'-'+m.field;if(!d.has(key)||String(d.get(key)).trim()==='')throw Error(a.name+'の'+(m.field==='pp'?(a.ppMode==='creation'?'固定追加PP（創造1〜10PPを除く）':'消費PP'):'必要スペック')+'を入力してください');const value=n(key);if(m.field==='pp'&&value<0)throw Error('消費PPは0以上です');resolved.push({a,field:m.field,value});}));}
  char.name=String(d.get('name')).trim();if(!char.name)throw Error('キャラクター名を入力してください');char.activation=d.get('activation');
  for(const k of Object.keys(char.stats)){if(['params','skills'].includes(k))continue;if(d.has(k))char.stats[k]=n(k);}
  char.stats.params=char.stats.params.map((_,i)=>n('param'+i));for(const k of Y.skillNames)char.stats.skills[k]=n('skill-'+k);
  const bp=readBPForm(f);
  if(isNew){for(const k of['hp','pp','rage','factor','spent','hpMax','ppMax'])char.state[k]=n('state-'+k);if(char.state.spent<0||char.state.pp<0||char.state.rage<0||char.state.hpMax<1||char.state.ppMax<0)throw Error('状態値の範囲を確認してください');for(const item of resolved)item.a[item.field]=item.value;for(const a of char.actions)delete a.importMissing;Y.setBP(char,bp,{initial:true,previousPPBonus});db.characters.push(char);db.activeId=char.id;pendingImport=null;draft=[];}
  else {if(JSON.stringify(bp)!==JSON.stringify(Y.bpConfig(original.state))||previousPPBonus!==Y.bpBonuses(char,{...char.state,bp}).ppMax)Y.setBP(char,bp,{previousPPBonus});db.characters[db.characters.findIndex(x=>x.id===char.id)]=char;}
 }
 else if(f.id==='condition-form'){Y.applyCondition(c(),conditionValues(f));}
 else if(f.id==='inventory-form'){
  const a={...editingOwned,name:String(d.get('name')).trim(),group:d.get('group'),quantity:n('quantity'),pp:n('pp'),hp:n('hp'),factor:n('factor'),rage:n('rage'),useLimit:n('useLimit'),usePeriod:d.get('usePeriod'),pressure:d.get('pressure')===''?null:n('pressure'),passive:d.has('passive'),main:d.has('main'),note:String(d.get('note')),needsReview:false,phases:Object.keys(Y.phases).filter(k=>d.has('phase-'+k))};
  if(!a.name||!a.phases.length||[a.quantity,a.pp,a.hp,a.factor,a.rage,a.useLimit].some(x=>x<0))throw Error('名前・コスト・宣言フェイズを確認してください');
  if(c().actions.some(x=>x.id!==a.id&&x.owned&&x.group===a.group&&x.name.normalize('NFKC')===a.name.normalize('NFKC')))throw Error('登録済みです。既存の所持品を編集してください');
  a.owned=true;a.rulesEdited=true;a.consumable=a.group==='消費アイテム';if(a.consumable){a.level=true;a.max=99;}else delete a.level;
  const s=Y.clone(c().state);s.ownedStock=s.ownedStock||{};s.ownedUses=s.ownedUses||{};const remaining=n('remaining');if(remaining<0||a.useLimit&&!a.consumable&&remaining>a.useLimit)throw Error('残数・残り使用回数を確認してください');
  if(a.consumable)s.ownedStock[a.id]=remaining;else if(a.useLimit)s.ownedUses[Y.ownedUseKey(a,s)]=a.useLimit-remaining;
  c().actions=c().actions.filter(x=>x.id!==a.id);c().actions.push(a);Y.record(c(),'所持品を登録：'+a.name,s,{},'inventory');draft=draft.filter(r=>r.action.id!==a.id);
 }

 else if(f.id==='damage-form'){Y.takeDamage(c(),n('damageRaw'),d.get('damageKind'),String(d.get('damageNote')));}
 else if(f.id==='symptom-form'){
  const char=c(),state=Y.clone(char.state),key=f.dataset.key;
  Y.completePending(state,Number(f.dataset.index),key);
  const choice=d.get('symptom')||'回復活性',name=d.get('erosion')||choice;
  const cost=n('extraPP'),gain=Math.floor((state.spent+cost)/5)-Math.floor(state.spent/5);
  if(cost>state.pp)throw Error('追加消費が残りPPを超えています。実際に消費した値を入力してください');
  state.hp=Math.min(state.hpMax,state.hp+n('healHP')-n('damage'));
  state.pp=Math.min(state.ppMax,state.pp+n('healPP')-cost);
  state.spent+=cost;state.factor+=gain;state.rage+=n('rise')+(name==='能力異常'?2:0);
  if(n('penalty'))state.buffs.push({id:Y.id(),name,target:'self',active:true,endRound:state.round,effects:['hit','dodge'].map(stat=>({stat,flat:-n('penalty'),dice:0,mult:1})),stat:'hit',flat:-n('penalty'),dice:0,mult:1});
  Y.appendRagePending(state,char.state.rage,char.activation);
  const title=key+' ／ '+(choice===name?name:choice+'：'+name);
  Y.record(char,title,state,{note:[title,d.get('target')].filter(Boolean).join(' ／ '),result:Object.fromEntries(d),spent:cost,gained:gain},'adjust');
 }
 else if(f.id==='adjust-form'){const char=c(),s=Y.clone(char.state),cost=n('costPP');if(cost<0||cost>s.pp)throw Error('消費PPは0〜残PPの範囲で指定してください');const gain=Math.floor((s.spent+cost)/5)-Math.floor(s.spent/5);s.hpMax=n('hpMax');s.ppMax=n('ppMax');s.hp=Math.min(s.hpMax,s.hp+n('hp'));s.pp=Math.min(s.ppMax,s.pp-cost+n('pp'));if(s.pp<0)throw Error('PPが0未満になります');s.rage=Math.max(0,s.rage+cost+n('rage'));s.factor+=n('factor')+gain;s.spent+=cost;const deltas={};for(const a of char.actions)if(a.owned&&['SPE','カルマ'].includes(a.group)&&a.useLimit)deltas[a.id]=n('uses-'+a.id);Y.adjustAbilityUses(char,s,deltas);if(f.dataset.resolve==='true')Y.completePending(s,Number(f.dataset.pendingIndex),f.dataset.pendingKey);Y.appendRagePending(s,char.state.rage,char.activation);Y.record(char,String(d.get('reason')),s,{pp:cost,spent:cost,gained:gain,note:String(d.get('reason'))},'adjust');}
 else if(f.id==='buff-form'){const s=Y.clone(c().state),b={id:f.dataset.id,name:String(d.get('name')),target:d.get('target'),stat:d.get('stat'),flat:n('flat'),dice:n('dice'),mult:Number(d.get('mult')),endRound:d.get('endRound')?n('endRound'):null,active:d.has('active')};b.effects=Array.from(f.querySelectorAll('.buff-effect')).map(row=>({stat:row.querySelector('[name=stat]').value,flat:Number(row.querySelector('[name=flat]').value),dice:Number(row.querySelector('[name=dice]').value),mult:Number(row.querySelector('[name=mult]').value)}));if(!b.effects.length||b.effects.some(e=>!e.stat||![e.flat,e.dice,e.mult].every(Number.isFinite)))throw Error('補正値を確認してください');if(!b.name.trim())throw Error('補正名を入力してください');s.buffs=s.buffs.filter(x=>x.id!==b.id);s.buffs.push(b);Y.record(c(),'補正を登録：'+b.name,s,{},'buff');}
 else if(f.id==='custom-form'){const a={...c().actions.find(x=>x.id===f.dataset.id),id:f.dataset.id,name:String(d.get('name')),pp:n('pp'),ppMode:d.get('ppMode')||'fixed',hp:n('hp'),factor:n('factor'),rage:n('rage'),spec:n('spec'),group:d.get('group'),attack:d.get('attack')||null,main:d.has('main'),note:String(d.get('note')),phases:Object.keys(Y.phases).filter(k=>d.has('phase-'+k))};if(!a.name.trim()||!a.phases.length)throw Error('名前と宣言可能なフェイズを指定してください');if(!['fixed','creation'].includes(a.ppMode))throw Error('PPの決め方を確認してください');if([a.pp,a.hp,a.factor,a.rage].some(x=>x<0))throw Error('コストは0以上にしてください');c().actions=c().actions.filter(x=>x.id!==a.id);c().actions.push(a);}
 else return;
 save();$('#modal').close();render();toast('保存しました');
 }catch(err){toast(err.message);}});
function bindImport(doc){doc.querySelector('#xlsx-file').addEventListener('change',async e=>{
 const file=e.target.files[0];if(!file)return;const mode=importMode,targetId=c()?.id;
 withSurface(doc,()=>toast('キャラシートを読み込んでいます…'));
 try{const char=await readCharacterXlsx(file,mode);withSurface(doc,()=>{
  if(mode==='inventory'){const target=db.characters.find(x=>x.id===targetId);if(!target)throw Error('読込先のキャラクターが見つかりません');const added=Y.mergeOwned(target,char);save();render();toast(added+'件の所持品を追加しました（登録済みの残数は保持）');}
  else characterDialog(char,true);
 });}catch(err){withSurface(doc,()=>modal('読み込めませんでした',`<div class="error">${esc(err.message)}</div><div class="form-actions"><button data-do="close">閉じる</button></div>`));}finally{e.target.value='';}
});}
bindImport(document);
$('#json-file').addEventListener('change',async e=>{const file=e.target.files[0];if(!file)return;try{if(file.size>30*1024*1024)throw Error('30MB以下のバックアップを選んでください');const imported=Y.validateDatabase(JSON.parse(await file.text()));for(const char of imported.characters){char.id=Y.id();char.name+='（復元）';db.characters.push(char);}db.activeId=db.characters.at(-1)?.id;if(storageError)throw Error('元データ保護のため保存を停止しています。元データを書き出し、別ブラウザでこのバックアップを復元してください。');save();$('#modal').close();render();toast(imported.characters.length+'件を追加しました。既存データは保持しています。');}catch(err){toast('復元できませんでした：'+err.message);}finally{e.target.value='';}});
// Character storage is owned by UlfStorage; legacy localStorage events must not block host writes.
function notifyLycoris(event){if(!firefoxMode||!event)return;const changes=[['hp','HP'],['pp','PP'],['rage','暴走率'],['factor','因子D'],['spent','総消費']].filter(([k])=>event.before[k]!==event.after[k]).map(([k,label])=>`${label} ${event.before[k]} → ${event.after[k]}`);const text=`【ウールヴハム】${c().name}：${event.type==='rollback'?'巻き戻し':'宣言登録'}\n${event.title}\n${changes.join(' / ')||'リソースの変動なし'}`;window.dispatchEvent(new CustomEvent('ulfhamr-history-notify',{detail:{id:event.id,characterId:c().id,text}}));}
window.UlfhamrLycoris={
 tokenSnapshot(){return c()?Y.clone(c()):null;},
 snapshot(){const char=c();return char?{id:char.id,name:char.name,compareMental:comparison().mental,compareEnemyKey:comparison().enemyKey,compareOwnKey:comparison().ownKey,opponent:Y.clone(char.state.opponent),values:{...Object.fromEntries(['hp','pp','rage','factor','spent'].map(k=>[k,char.state[k]])),initiative:Y.effective(char,'initiative').fixed,info:char.state.info||''}}:null;},
 importOpponent(id,mental,values){
  const char=c();if(!char||char.id!==id||comparison().mental!==mental||values.checkKey&&values.checkKey!==comparison().enemyKey)throw Error('キャラクターか比較条件が変わりました。相手を選び直してください。');
  if(storageError)throw Error('保存データを保護中です。');
  for(const k of ['hp','fixed','dice','defense','resist','rage'])if(!Number.isSafeInteger(values[k]))throw Error('相手の数値を確認してください。');
  if(values.dice<0||values.dice>20||values.rage<0)throw Error('相手のダイス数・暴走率の範囲を確認してください。');
  if(!['－','覚醒型','増強型','反応型','感覚型','回復型'].includes(values.activation))throw Error('活性タイプを確認してください。');
  if(values.checks!==undefined&&!Y.validOpponentChecks(values.checks))throw Error('相手の判定値を確認してください。');
  const original=Y.clone(char),s=Y.clone(char.state),key=comparison().enemyKey;s.opponent={...values,name:String(values.name),checkKey:key,checks:{...values.checks,[key]:{fixed:values.fixed,dice:values.dice}}};
  Y.record(char,'リコリスの比較対象：'+s.opponent.name,s,{source:'lycoris'},'opponent');
  if(!save()){db.characters[db.characters.indexOf(char)]=original;throw Error('保存に失敗しました。');}render();toast('相手の数値を期待値計算に反映しました');
 },
 importValues(id,expected,values){
  const char=c();if(!char||char.id!==id)throw Error('対象キャラクターが変わりました。もう一度読み込んでください。');
  if(storageError)throw Error('保存データを保護中のため変更できません。');
  for(const [key,value] of Object.entries(expected))if((key==='info'?(char.state.info||''):char.state[key])!==value)throw Error('ウールヴハム側の状態が変更されています。もう一度読み込んでください。');
  const next=Y.clone(char.state),allowed=['hp','pp','rage','factor','spent','info'];
  for(const [key,value] of Object.entries(values)){
   if(!allowed.includes(key)||(key==='info'?typeof value!=='string':!Number.isSafeInteger(value)))throw Error('取り込む数値を確認してください。');
   if(['pp','rage','spent'].includes(key)&&value<0)throw Error(key+'は0以上で入力してください。');
   if(key==='hp'&&value>next.hpMax||key==='pp'&&value>next.ppMax)throw Error('最大値を超えています。ウールヴハム側の最大値を確認してください。');
   next[key]=value;
  }
  if(!Object.keys(values).length)throw Error('取り込む項目がありません。');
  const index=db.characters.findIndex(x=>x.id===char.id),original=Y.clone(char);
  Y.record(char,'リコリスから状態を反映',next,{source:'lycoris'},'adjust');
  if(!save()){db.characters[index]=original;throw Error('保存に失敗しました。');}render();toast('リコリスの状態を履歴に記録しました');
 },
};
render();
})();
